---
name: Deep Space OS
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#89ceff'
  on-tertiary: '#00344d'
  tertiary-container: '#23acf1'
  on-tertiary-container: '#003d59'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  stats-num:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  grid-gap: 1rem
  container-padding: 2rem
  card-padding: 1.5rem
  element-gap: 0.75rem
  stack-compact: 0.5rem
---

## Brand & Style
The design system is engineered for high-performance personal management, functioning as a "digital cockpit" for a user's life. The aesthetic is **Modern Minimalism** with a focus on **Bento Grid** layouts to organize disparate data streams into a cohesive, glanceable interface. 

The emotional response should be one of "calm control"—reducing cognitive load through deep-space backgrounds and vibrant, purposeful accents. The UI utilizes a "glass-on-slate" approach, where information is layered on subtle, semi-transparent containers that feel integrated rather than floating. High contrast is maintained for critical data points, while secondary utility elements recede into the background.

## Colors
The palette is centered around a **Dark Theme** default. The foundation is `Deep Slate (#0F172A)`, providing a low-light environment that reduces eye strain during long-term use.

- **Primary (Soft Emerald):** Used for positive progress, completed habits, and "Go" actions.
- **Secondary (Violet):** Used for creative tasks, deep work sessions, and focus modes.
- **Tertiary (Sky Blue):** Used for informational statuses, scheduling, and weather data.
- **Surface & Borders:** Tonal variations of slate are used to create the bento grid structure. Borders are kept thin and subtle to maintain a sleek, modern feel without visual clutter.

## Typography
This design system utilizes **Inter** for all primary interface elements to ensure maximum legibility and a neutral, professional tone. **JetBrains Mono** is introduced for labels and metadata to lean into the "OS" and technical dashboard aesthetic.

- **Scale:** Use `display-lg` for dashboard clock or primary daily targets.
- **Labels:** Always use `label-caps` for section headers within bento cards.
- **Readability:** Body text uses high-contrast white or light gray against the deep slate background. Tight letter spacing is applied to large headings to maintain the sleek, modern appearance.

## Layout & Spacing
The layout follows a **Fluid Bento Grid** model. Elements are housed in modular cards that snap to a 12-column grid system. 

- **Desktop:** 12-column grid with 16px (`1rem`) gaps. Cards can span 3, 4, 6, or 12 columns depending on data density.
- **Tablet:** 6-column grid with 16px gaps.
- **Mobile:** Single column stack with 12px gaps and 16px side margins.
- **Rhythm:** Spacing follows an 8px base unit. Internal card padding is consistently `1.5rem` to give the data room to breathe.

## Elevation & Depth
Depth is achieved through **Tonal Layering** and **Subtle Outlines** rather than heavy shadows.

1.  **Level 0 (Base):** Background `Deep Slate (#0F172A)`.
2.  **Level 1 (Cards):** Surface `Slate (#1E293B)` with a `1px` solid border in `Slate-700 (#334155)`.
3.  **Level 2 (Popovers/Modals):** Same surface as Level 1 but with a subtle `20%` opacity black shadow and a slightly lighter border to indicate "lift."

Hover states on cards should trigger a subtle border color shift to the `Primary` or `Secondary` accent color, signaling interactivity without moving the element.

## Shapes
The shape language is defined by **Soft Geometricism**. All primary bento containers use a `1rem` (16px) corner radius to soften the technical nature of the dashboard. Small interactive elements like buttons and input fields use a `0.5rem` (8px) radius. 

Status indicators and progress bars use fully rounded (pill-shaped) caps to differentiate "active" data from "structural" containers.

## Components
- **Bento Cards:** The primary container. Must include a `label-caps` header and optional icon.
- **Action Buttons:** Filled buttons use the accent colors with white text. Ghost buttons use a `1px` border matching the accent color.
- **Habit Checkboxes:** Large, custom-styled squares (24x24px). When checked, they should fill with a gradient of the Primary color and trigger a micro-scale-up animation.
- **Progress Bars:** Thin (4px - 8px height) tracks with a glowing leading edge. Use the Sky Blue tertiary color for general progress and Soft Emerald for completion.
- **Heatmaps:** For habit tracking, use a grid of 12x12px squares. Empty states are the background color; active states are varying opacities of the Soft Emerald accent.
- **Input Fields:** Minimalist design with only a bottom border or a very subtle filled background. Focus state should highlight the border in Sky Blue.
- **Charts:** Use thin lines (2px) for line charts with a subtle gradient fill below the line to create volume without clutter.