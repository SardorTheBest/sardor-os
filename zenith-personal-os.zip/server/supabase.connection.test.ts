import { describe, expect, it } from "vitest";

const supabaseUrl = process.env.SUPABASE_URL;
const publishableKey = process.env.SUPABASE_PUBLISHABLE_KEY;

describe("Supabase connection", () => {
  it("accepts the configured publishable key on the public settings endpoint", async () => {
    expect(supabaseUrl, "SUPABASE_URL must be configured").toBeTruthy();
    expect(publishableKey, "SUPABASE_PUBLISHABLE_KEY must be configured").toBeTruthy();

    const response = await fetch(`${supabaseUrl}/auth/v1/settings`, {
      headers: { apikey: publishableKey! },
    });

    expect(response.ok, `Supabase returned ${response.status}`).toBe(true);
    const payload = await response.json() as { external?: Record<string, unknown> };
    expect(payload).toHaveProperty("external");
  }, 15_000);
});
