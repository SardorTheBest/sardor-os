const endpoint = process.argv[2] || 'http://127.0.0.1:9226';
const pages = await (await fetch(`${endpoint}/json/list`)).json();
const page = pages.find((item) => item.type === 'page');
const socket = new WebSocket(page.webSocketDebuggerUrl);
await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
let id = 0;
const requests = new Map();
socket.addEventListener('message', (event) => { const message = JSON.parse(event.data); if (requests.has(message.id)) { requests.get(message.id)(message.result); requests.delete(message.id); } });
async function evaluate(source) {
  const requestId = ++id;
  socket.send(JSON.stringify({ id: requestId, method: 'Runtime.evaluate', params: { expression: `(() => { ${source} })()`, returnByValue: true } }));
  const result = await new Promise((resolve) => requests.set(requestId, resolve));
  return result.result?.value;
}
await evaluate(`
  document.querySelector('[data-view=calendar]').click();
  return true;
`);
await new Promise((resolve) => setTimeout(resolve, 100));
const before = await evaluate(`
  return {
    title: document.querySelector('[data-calendar-title]')?.textContent,
    previousButtons: document.querySelectorAll('[data-calendar-action=previous]').length,
    moduleMode: document.querySelector('[data-calendar-module]')?.dataset.calendarMode,
  };
`);
const eventProbe = await evaluate(`
  const root = document.querySelector('[data-calendar-module]');
  const button = document.querySelector('[data-calendar-action=previous]');
  root.addEventListener('click', (event) => {
    window.__calendarProbe = {
      target: event.target?.tagName,
      action: event.target?.closest('[data-calendar-action]')?.dataset.calendarAction || null,
      disabled: button.disabled,
    };
  }, { capture: true, once: true });
  button?.click();
  return window.__calendarProbe;
`);
await new Promise((resolve) => setTimeout(resolve, 100));
const after = await evaluate(`return { title: document.querySelector('[data-calendar-title]')?.textContent, moduleMode: document.querySelector('[data-calendar-module]')?.dataset.calendarMode };`);
console.log(JSON.stringify({ before, eventProbe, after }));
socket.close();
