const endpoint = process.argv[2] || 'http://127.0.0.1:9226';
const targets = await (await fetch(`${endpoint}/json/list`)).json();
const target = targets.find((item) => item.type === 'page');
const socket = new WebSocket(target.webSocketDebuggerUrl);
await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
socket.send(JSON.stringify({ id: 1, method: 'Runtime.evaluate', params: {
  expression: `JSON.stringify({ location: location.href, appState: window.appState ? { books: window.appState.books, stats: window.appState.stats } : null, stored: JSON.parse(localStorage.getItem('zenith-personal-os:v3') || 'null') })`,
  returnByValue: true,
} }));
socket.addEventListener('message', (event) => { console.log(JSON.parse(event.data).result.result.value); socket.close(); });
