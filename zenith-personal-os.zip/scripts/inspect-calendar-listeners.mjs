const endpoint = process.argv[2] || 'http://127.0.0.1:9226';
const targets = await (await fetch(`${endpoint}/json/list`)).json();
const page = targets.find((item) => item.type === 'page');
const socket = new WebSocket(page.webSocketDebuggerUrl);
const pending = new Map();
let id = 0;
socket.addEventListener('message', (event) => { const message = JSON.parse(event.data); if (pending.has(message.id)) { pending.get(message.id)(message.result); pending.delete(message.id); } });
await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
function send(method, params) { const requestId = ++id; socket.send(JSON.stringify({ id: requestId, method, params })); return new Promise((resolve) => pending.set(requestId, resolve)); }
const evaluated = await send('Runtime.evaluate', { expression: 'document.querySelector("[data-calendar-module]")' });
const listeners = await send('DOMDebugger.getEventListeners', { objectId: evaluated.result.objectId });
console.log(JSON.stringify(listeners.listeners.map((listener) => ({ type: listener.type, useCapture: listener.useCapture }))));
socket.close();
