/**
 * Browser-level smoke test for the local-first Daily To-Do List.
 * Starts against a Chromium remote-debugging target supplied as argv[2].
 */
const endpoint = process.argv[2] || 'http://127.0.0.1:9225';

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function getTarget() {
  const pages = await (await fetch(`${endpoint}/json/list`)).json();
  const page = pages.find((item) => item.type === 'page');
  if (!page) throw new Error('Chromium page target was not found.');
  return page.webSocketDebuggerUrl;
}

async function connect(url) {
  const socket = new WebSocket(url);
  const requests = new Map();
  let requestId = 0;
  socket.addEventListener('message', (event) => {
    const message = JSON.parse(event.data);
    if (message.id && requests.has(message.id)) {
      const { resolve, reject } = requests.get(message.id);
      requests.delete(message.id);
      if (message.error) reject(new Error(message.error.message));
      else resolve(message.result);
    }
  });
  await new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true });
    socket.addEventListener('error', reject, { once: true });
  });
  return {
    async send(method, params = {}) {
      const id = ++requestId;
      socket.send(JSON.stringify({ id, method, params }));
      return new Promise((resolve, reject) => requests.set(id, { resolve, reject }));
    },
    close() { socket.close(); },
  };
}

const expression = (code) => `(() => { ${code} })()`;

const url = await getTarget();
const cdp = await connect(url);

async function evaluate(code) {
  const result = await cdp.send('Runtime.evaluate', {
    expression: expression(code),
    awaitPromise: true,
    returnByValue: true,
  });
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.text);
  return result.result.value;
}

for (let attempt = 0; attempt < 50; attempt += 1) {
  const ready = await evaluate('return Boolean(document.querySelector("[data-todo-module]"));');
  if (ready) break;
  await sleep(100);
  if (attempt === 49) throw new Error('TodoModule did not mount in time.');
}

await evaluate(`
  window.appState.getTasks().forEach((task) => window.appState.deleteTask(task.id));
  return true;
`);
await sleep(80);

await evaluate(`
  const input = document.querySelector('[data-todo-quick-input]');
  input.value = 'Проверить активный контур';
  document.querySelector('[data-todo-quick-form]').requestSubmit();
  return true;
`);
await sleep(120);
assert(await evaluate('return document.querySelectorAll("[data-task-id]").length === 1;'), 'Quick add did not render a task card.');
assert(await evaluate('return localStorage.getItem("zenith-personal-os:v3").includes("\\\"isSynced\\\":false");'), 'Quick add did not persist the unsynced local-first task.');

await evaluate('document.querySelector("[data-action=toggle-task]").click(); return true;');
await sleep(120);
assert(await evaluate('return document.querySelector("[data-todo-completed-section]").hidden === false;'), 'Completed section did not become visible.');
assert(await evaluate('return document.querySelector(".task-card--completed") !== null;'), 'Completed task did not receive its visual state.');

await evaluate('document.querySelector("[data-action=edit-task]").click(); return true;');
await sleep(80);
assert(await evaluate('return document.querySelector(".task-dialog").open === true;'), 'Edit dialog did not open.');
await evaluate(`
  const form = document.querySelector('.task-dialog form');
  form.elements.title.value = 'Проверить обновлённый контур';
  form.elements.dueDate.value = '2099-12-31';
  form.requestSubmit();
  return true;
`);
await sleep(120);
assert(await evaluate('return document.body.textContent.includes("Проверить обновлённый контур");'), 'Edited task title was not rendered.');

await evaluate('document.querySelector("[data-filter=upcoming]").click(); return true;');
await sleep(80);
assert(await evaluate('return document.querySelector("[data-todo-completed-section]").hidden === false;'), 'Upcoming filter did not retain the future completed task.');

await evaluate('window.confirm = () => true; document.querySelector("[data-action=delete-task]").click(); return true;');
await sleep(120);
assert(await evaluate('return document.querySelectorAll("[data-task-id]").length === 0;'), 'Delete did not remove the task card.');

const browserErrors = await cdp.send('Runtime.evaluate', {
  expression: 'window.__sprint2SmokeComplete = true',
  returnByValue: true,
});
assert(Boolean(browserErrors), 'Smoke-test completion signal failed.');
cdp.close();
console.log('TodoModule browser smoke test passed.');
