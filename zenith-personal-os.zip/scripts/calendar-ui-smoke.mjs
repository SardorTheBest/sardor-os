/** Browser smoke test for CalendarModule. Run against a Chromium CDP endpoint. */
const endpoint = process.argv[2] || 'http://127.0.0.1:9226';
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const assert = (condition, message) => { if (!condition) throw new Error(message); };

const targets = await (await fetch(`${endpoint}/json/list`)).json();
const target = targets.find((item) => item.type === 'page');
if (!target) throw new Error('Не найдена страница для проверки календаря.');
const socket = new WebSocket(target.webSocketDebuggerUrl);
const pending = new Map();
let requestId = 0;
socket.addEventListener('message', (event) => {
  const message = JSON.parse(event.data);
  if (!pending.has(message.id)) return;
  const { resolve, reject } = pending.get(message.id);
  pending.delete(message.id);
  if (message.error) reject(new Error(message.error.message));
  else resolve(message.result);
});
await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });

async function evaluate(source) {
  const id = ++requestId;
  socket.send(JSON.stringify({ id, method: 'Runtime.evaluate', params: {
    expression: `(() => { ${source} })()`, awaitPromise: true, returnByValue: true,
  } }));
  const result = await new Promise((resolve, reject) => pending.set(id, { resolve, reject }));
  if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text);
  return result.result.value;
}

for (let attempt = 0; attempt < 40; attempt += 1) {
  if (await evaluate('return Boolean(window.appState && document.querySelector("[data-view=calendar]"));')) break;
  await sleep(100);
  if (attempt === 39) throw new Error('Приложение не готово к calendar smoke-test.');
}

await evaluate('document.querySelector("[data-view=calendar]").click(); return true;');
await sleep(150);
assert(await evaluate('return !document.querySelector("[data-app-view=tasks]").hidden;'), 'Маршрут календаря не открыл связанный экран задач.');
assert(await evaluate('return document.querySelectorAll(".calendar-day-cell").length >= 35;'), 'Месячная сетка календаря не отрисовалась.');
const initialTitle = await evaluate('return document.querySelector("[data-calendar-title]").textContent;');
await evaluate('document.querySelector("[data-calendar-action=previous]").click(); return true;');
await sleep(80);
assert(await evaluate(`return document.querySelector('[data-calendar-title]').textContent !== ${JSON.stringify(initialTitle)};`), 'Кнопка предыдущего периода не изменила календарный заголовок.');
await evaluate('document.querySelector("[data-calendar-action=next]").click(); return true;');
await sleep(80);
assert(await evaluate(`return document.querySelector('[data-calendar-title]').textContent === ${JSON.stringify(initialTitle)};`), 'Кнопка следующего периода не вернула исходный период.');

await evaluate('document.querySelector("[data-calendar-mode=week]").click(); return true;');
await sleep(80);
assert(await evaluate('return document.querySelector("[data-calendar-module]").dataset.calendarMode === "week" && Boolean(document.querySelector(".calendar-week-grid"));'), 'Недельный режим не активировался.');
await evaluate('document.querySelector("[data-calendar-mode=day]").click(); return true;');
await sleep(80);
assert(await evaluate('return document.querySelector("[data-calendar-module]").dataset.calendarMode === "day" && Boolean(document.querySelector(".calendar-day-agenda"));'), 'Дневной режим не активировался.');
await evaluate('document.querySelector("[data-calendar-mode=month]").click(); return true;');
await sleep(80);

await evaluate(`
  const cell = document.querySelector('.calendar-day-cell:not(.calendar-day-cell--muted)');
  cell.click();
  return true;
`);
await sleep(100);
assert(await evaluate('return document.querySelector(".task-dialog").open;'), 'Клик по ячейке не открыл создание задачи.');
const createdTitle = 'Календарная регрессия';
await evaluate(`
  const form = document.querySelector('.task-dialog form');
  form.elements.title.value = ${JSON.stringify(createdTitle)};
  form.elements.dueTime.value = '09:00';
  form.requestSubmit();
  return true;
`);
await sleep(150);
assert(await evaluate(`return Array.from(document.querySelectorAll('[data-calendar-task-id]')).some((item) => item.textContent.includes(${JSON.stringify(createdTitle)}));`), 'Новая задача не появилась в календарной ячейке.');
await evaluate(`Array.from(document.querySelectorAll('[data-calendar-task-id]')).find((item) => item.textContent.includes(${JSON.stringify(createdTitle)})).click(); return true;`);
await sleep(100);
assert(await evaluate(`return document.querySelector('.task-dialog').open && document.querySelector('.task-dialog [name=title]').value === ${JSON.stringify(createdTitle)};`), 'Клик по task pill не открыл редактирование нужной задачи.');
await evaluate('document.querySelector(".task-dialog [data-action=close-task-dialog]").click(); return true;');
socket.close();
console.log('CalendarModule browser smoke test passed.');
