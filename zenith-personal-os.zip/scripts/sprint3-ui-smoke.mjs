/** Browser-level smoke test for the three local-first Sprint 3 screens. */
const endpoint = process.argv[2] || 'http://127.0.0.1:9226';
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const assert = (condition, message) => { if (!condition) throw new Error(message); };

async function pageSocketUrl() {
  const targets = await (await fetch(`${endpoint}/json/list`)).json();
  const page = targets.find((target) => target.type === 'page');
  if (!page) throw new Error('Не найдена страница headless-браузера.');
  return page.webSocketDebuggerUrl;
}

async function connect(url) {
  const socket = new WebSocket(url);
  const pending = new Map();
  let id = 0;
  socket.addEventListener('message', (event) => {
    const message = JSON.parse(event.data);
    if (!pending.has(message.id)) return;
    const { resolve, reject } = pending.get(message.id);
    pending.delete(message.id);
    if (message.error) reject(new Error(message.error.message));
    else resolve(message.result);
  });
  await new Promise((resolve, reject) => {
    socket.addEventListener('open', resolve, { once: true });
    socket.addEventListener('error', reject, { once: true });
  });
  return {
    send(method, params = {}) {
      const requestId = ++id;
      socket.send(JSON.stringify({ id: requestId, method, params }));
      return new Promise((resolve, reject) => pending.set(requestId, { resolve, reject }));
    },
    close() { socket.close(); },
  };
}

let cdp = await connect(await pageSocketUrl());
async function evaluate(source) {
  const result = await cdp.send('Runtime.evaluate', {
    expression: `(() => { ${source} })()`, awaitPromise: true, returnByValue: true,
  });
  if (result.exceptionDetails) {
    throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text);
  }
  return result.result.value;
}

for (let attempt = 0; attempt < 50; attempt += 1) {
  if (await evaluate('return Boolean(document.querySelector("[data-dashboard-module]"));')) break;
  await sleep(100);
  if (attempt === 49) throw new Error('Приложение не смонтировалось вовремя.');
}

await evaluate('document.querySelector("[data-view=dashboard]").click(); return true;');
await sleep(80);
assert(await evaluate('return !document.querySelector("[data-app-view=dashboard]").hidden;'), 'Дашборд не открылся по умолчанию.');
assert(await evaluate('return Boolean(window.appState) && Array.isArray(window.appState.habits);'), 'Единый AppState не гидрирован при старте приложения.');
await evaluate('document.querySelector("[data-view=habits]").click(); return true;');
await sleep(100);
assert(await evaluate('return !document.querySelector("[data-app-view=habits]").hidden;'), 'Маршрут привычек не переключился.');
const habitBefore = await evaluate('return JSON.parse(localStorage.getItem("zenith-personal-os:v3")).habits[0].history;');
await evaluate('document.querySelector("[data-action=toggle-habit]").click(); return true;');
await sleep(100);
const habitAfter = await evaluate('return JSON.parse(localStorage.getItem("zenith-personal-os:v3")).habits[0].history;');
assert(JSON.stringify(habitBefore) !== JSON.stringify(habitAfter), 'Чекбокс привычки не изменил local-first history.');
assert(await evaluate('return window.appState.stats.todayCompletedHabits >= 0;'), 'Чек-ин привычки не пересчитал derived stats AppState.');
await evaluate('document.querySelector("[data-date][data-percent]").click(); return true;');
assert(await evaluate('return document.querySelector("[data-heatmap-tooltip]").textContent.includes("выполнено");'), 'Heatmap не обновила подсказку.');

await evaluate('document.querySelector("[data-view=books]").click(); return true;');
await sleep(100);
assert(await evaluate('return !document.querySelector("[data-app-view=books]").hidden;'), 'Маршрут книги не переключился.');
const pagesBefore = await evaluate('return JSON.parse(localStorage.getItem("zenith-personal-os:v3")).books[0].readPages;');
await evaluate('document.querySelector("[data-action=start-timer]").click(); return true;');
await sleep(1100);
await evaluate('document.querySelector("[data-action=stop-timer]").click(); return true;');
await sleep(100);
assert(await evaluate('return document.querySelector(".reading-session-dialog").open;'), 'Остановка чтения не открыла форму страниц.');
await evaluate('const form = document.querySelector("[data-pages-form]"); form.elements.pages.value = "4"; form.requestSubmit(); return true;');
await sleep(130);
const pagesAfter = await evaluate('return JSON.parse(localStorage.getItem("zenith-personal-os:v3")).books[0].readPages;');
assert(pagesAfter === pagesBefore + 4, 'Сессия чтения не обновила readPages.');
assert(await evaluate('return window.appState.getBookById(window.appState.books[0].id).readPages === window.appState.books[0].readPages;'), 'AppState не отразил обновлённый прогресс книги.');
await evaluate('const quote = document.querySelector("textarea[name=quote]"); quote.value = "Проверенная цитата Sprint 3"; quote.closest("form").requestSubmit(); return true;');
await sleep(130);
assert(await evaluate('return document.body.textContent.includes("Проверенная цитата Sprint 3");'), 'Форма цитаты не отрисовала новую запись.');
await evaluate('document.querySelector("[data-action=back-dashboard]").click(); return true;');
await sleep(80);
assert(await evaluate('return !document.querySelector("[data-app-view=dashboard]").hidden;'), 'Возврат на дашборд не сработал.');
assert(await evaluate(`
  const state = window.appState;
  const persisted = JSON.parse(localStorage.getItem('zenith-personal-os:v3') || '{}');
  return Boolean(state && state.books?.[0] && persisted.books?.[0]
    && state.books[0].readPages === persisted.books[0].readPages);
`), 'Состояние после reload не гидрировалось из localStorage.');
cdp.close();
console.log('Sprint 3 browser smoke test passed.');
