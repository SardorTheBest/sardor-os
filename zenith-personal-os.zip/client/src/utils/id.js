/**
 * Design reminder — Deep-Space Instrument Panel:
 * IDs are invisible infrastructure supporting quick, reliable local interactions.
 */
export function createId(prefix) {
  const value = globalThis.crypto?.randomUUID?.()
    || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  return `${prefix}_${value}`;
}
