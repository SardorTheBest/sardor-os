/**
 * Design reminder — Deep-Space Instrument Panel:
 * tasks are ledger entries on tonal navy surfaces; emerald indicates completion and user tag colors remain data-driven signals.
 */
import { createId } from '../../utils/id.js';

const FILTERS = new Set(['all', 'today', 'upcoming']);
const MS_IN_DAY = 24 * 60 * 60 * 1000;

function getLocalDateKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function parseLocalDate(dateKey) {
  if (!dateKey) return null;
  const [year, month, day] = dateKey.split('-').map(Number);
  return new Date(year, month - 1, day);
}

function shortDateLabel(dateKey) {
  if (!dateKey) return 'Без срока';
  const today = getLocalDateKey();
  const tomorrow = getLocalDateKey(new Date(Date.now() + MS_IN_DAY));
  const yesterday = getLocalDateKey(new Date(Date.now() - MS_IN_DAY));
  if (dateKey === today) return 'Сегодня';
  if (dateKey === tomorrow) return 'Завтра';
  if (dateKey === yesterday) return 'Вчера';
  return new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'short' })
    .format(parseLocalDate(dateKey))
    .replace('.', '');
}

function toRgba(hex, alpha) {
  const normalized = String(hex || '#6B7280').replace('#', '');
  const value = normalized.length === 3
    ? normalized.split('').map((symbol) => symbol + symbol).join('')
    : normalized;
  const numeric = Number.parseInt(value, 16);
  if (Number.isNaN(numeric)) return `rgba(107, 114, 128, ${alpha})`;
  return `rgba(${(numeric >> 16) & 255}, ${(numeric >> 8) & 255}, ${numeric & 255}, ${alpha})`;
}

function taskSortValue(task) {
  if (!task.dueDate) return '9999-12-31T23:59';
  return `${task.dueDate}T${task.dueTime || '23:59'}`;
}

/**
 * Daily To-Do feature controller. It receives data only through StorageManager;
 * direct localStorage access is intentionally prohibited here.
 */
export class TodoModule {
  constructor({ storage, tags, root, notify = () => {} }) {
    if (!storage) throw new Error('TodoModule requires StorageManager.');
    if (!tags) throw new Error('TodoModule requires TagManager.');
    if (!root) throw new Error('TodoModule requires a root element.');

    this.storage = storage;
    this.tags = tags;
    this.root = root;
    this.notify = notify;
    this.filter = 'all';
    this.dialog = null;
    this.unsubscribe = null;
    this.onRootClick = this.onRootClick.bind(this);
    this.onQuickSubmit = this.onQuickSubmit.bind(this);
    this.onDialogClick = this.onDialogClick.bind(this);
    this.onFormSubmit = this.onFormSubmit.bind(this);
  }

  mount() {
    this.createDialog();
    this.root.addEventListener('click', this.onRootClick);
    this.root.querySelector('[data-todo-quick-form]').addEventListener('submit', this.onQuickSubmit);
    this.unsubscribe = this.storage.subscribe(() => this.render());
    this.render();
  }

  destroy() {
    this.root.removeEventListener('click', this.onRootClick);
    this.root.querySelector('[data-todo-quick-form]')?.removeEventListener('submit', this.onQuickSubmit);
    this.dialog?.removeEventListener('click', this.onDialogClick);
    this.dialog?.querySelector('form')?.removeEventListener('submit', this.onFormSubmit);
    this.dialog?.remove();
    this.unsubscribe?.();
  }

  setFilter(filter) {
    this.filter = FILTERS.has(filter) ? filter : 'all';
    this.render();
  }

  getFilteredTasks() {
    const today = getLocalDateKey();
    return this.storage.getTasks().filter((task) => {
      if (this.filter === 'today') return task.dueDate === today;
      if (this.filter === 'upcoming') return Boolean(task.dueDate && task.dueDate > today);
      return true;
    });
  }

  getSortedTaskGroups() {
    const tasks = this.getFilteredTasks();
    const active = tasks.filter((task) => !task.isCompleted)
      .sort((left, right) => taskSortValue(left).localeCompare(taskSortValue(right))
        || left.createdAt.localeCompare(right.createdAt));
    const completed = tasks.filter((task) => task.isCompleted)
      .sort((left, right) => right.updatedAt.localeCompare(left.updatedAt));
    return { active, completed };
  }

  createTask(data) {
    const task = this.storage.saveTask({
      id: createId('task'),
      title: data.title,
      description: data.description || '',
      isCompleted: false,
      dueDate: data.dueDate || null,
      dueTime: data.dueTime || null,
      tagId: data.tagId || null,
    });
    this.notify('Задача добавлена в локальный контур.', 'success');
    return task;
  }

  updateTask(taskId, data) {
    const task = this.storage.updateTask(taskId, {
      title: data.title,
      description: data.description || '',
      dueDate: data.dueDate || null,
      dueTime: data.dueTime || null,
      tagId: data.tagId || null,
    });
    this.notify('Параметры задачи обновлены.', 'success');
    return task;
  }

  toggleTask(taskId) {
    const task = this.storage.getTaskById(taskId);
    if (!task) return;
    this.storage.updateTask(taskId, { isCompleted: !task.isCompleted });
    this.notify(task.isCompleted ? 'Задача возвращена в активный контур.' : 'Задача отмечена как выполненная.', 'success');
  }

  deleteTask(taskId) {
    const task = this.storage.getTaskById(taskId);
    if (!task) return;
    const accepted = window.confirm(`Удалить задачу «${task.title}»?`);
    if (!accepted) return;
    this.storage.deleteTask(taskId);
    this.notify('Задача удалена из локального контура.', 'success');
  }

  render() {
    const { active, completed } = this.getSortedTaskGroups();
    const total = active.length + completed.length;
    const counter = this.root.querySelector('[data-todo-count]');
    const activeTarget = this.root.querySelector('[data-todo-active-list]');
    const completedTarget = this.root.querySelector('[data-todo-completed-list]');
    const completedSection = this.root.querySelector('[data-todo-completed-section]');
    const noResults = this.root.querySelector('[data-todo-no-results]');
    const activeCount = this.root.querySelector('[data-todo-active-count]');
    const completedCount = this.root.querySelector('[data-todo-completed-count]');

    counter.textContent = String(total).padStart(2, '0');
    activeCount.textContent = String(active.length).padStart(2, '0');
    completedCount.textContent = String(completed.length).padStart(2, '0');
    this.updateFilterControls();

    activeTarget.replaceChildren(...active.map((task) => this.createTaskCard(task)));
    completedTarget.replaceChildren(...completed.map((task) => this.createTaskCard(task)));
    completedSection.hidden = completed.length === 0;

    const noTasks = total === 0;
    noResults.hidden = !noTasks;
    this.root.querySelector('[data-todo-active-section]').hidden = noTasks;
    this.refreshIcons();
  }

  createTaskCard(task) {
    const tag = this.tags.getTagById(task.tagId);
    const card = document.createElement('article');
    card.className = `task-card${task.isCompleted ? ' task-card--completed' : ''}`;
    card.dataset.taskId = task.id;
    const tagColor = tag?.color || '#6B7280';
    card.style.setProperty('--task-tag-color', tagColor);
    card.style.setProperty('--task-tag-bg', toRgba(tagColor, 0.14));

    const checkbox = document.createElement('button');
    checkbox.type = 'button';
    checkbox.className = 'task-check';
    checkbox.dataset.action = 'toggle-task';
    checkbox.setAttribute('role', 'checkbox');
    checkbox.setAttribute('aria-checked', String(task.isCompleted));
    checkbox.setAttribute('aria-label', task.isCompleted ? 'Вернуть задачу в активные' : 'Отметить задачу как выполненную');
    checkbox.innerHTML = '<i data-lucide="check" aria-hidden="true"></i>';

    const content = document.createElement('div');
    content.className = 'task-card__content';
    const title = document.createElement('h4');
    title.className = 'task-card__title';
    title.textContent = task.title;
    content.append(title);

    if (task.description) {
      const description = document.createElement('p');
      description.className = 'task-card__description';
      description.textContent = task.description;
      content.append(description);
    }

    const metadata = document.createElement('div');
    metadata.className = 'task-card__metadata';
    if (task.dueDate || task.dueTime) metadata.append(this.createDueBadge(task));
    if (tag) metadata.append(this.createTagBadge(tag));
    if (!task.dueDate && !tag) {
      const localBadge = document.createElement('span');
      localBadge.className = 'task-meta task-meta--local';
      localBadge.textContent = 'LOCAL';
      metadata.append(localBadge);
    }
    content.append(metadata);

    const actions = document.createElement('div');
    actions.className = 'task-card__actions';
    actions.innerHTML = `
      <button class="task-action-button" type="button" data-action="edit-task" aria-label="Редактировать задачу"><i data-lucide="pencil" aria-hidden="true"></i></button>
      <button class="task-action-button task-action-button--delete" type="button" data-action="delete-task" aria-label="Удалить задачу"><i data-lucide="trash-2" aria-hidden="true"></i></button>
    `;

    card.append(checkbox, content, actions);
    return card;
  }

  createDueBadge(task) {
    const badge = document.createElement('span');
    const isOverdue = Boolean(task.dueDate && task.dueDate < getLocalDateKey() && !task.isCompleted);
    badge.className = `task-meta task-meta--due${isOverdue ? ' task-meta--overdue' : ''}`;
    badge.innerHTML = '<i data-lucide="calendar-clock" aria-hidden="true"></i><span></span>';
    const label = [shortDateLabel(task.dueDate), task.dueTime].filter(Boolean).join(' · ');
    badge.querySelector('span').textContent = label;
    return badge;
  }

  createTagBadge(tag) {
    const badge = document.createElement('span');
    badge.className = 'task-meta task-meta--tag';
    badge.style.setProperty('--tag-color', tag.color);
    badge.style.setProperty('--tag-color-bg', toRgba(tag.color, 0.15));
    badge.innerHTML = '<i aria-hidden="true"></i><span></span>';
    badge.querySelector('span').textContent = tag.name;
    return badge;
  }

  updateFilterControls() {
    this.root.querySelectorAll('[data-filter]').forEach((button) => {
      const selected = button.dataset.filter === this.filter;
      button.classList.toggle('filter-button--active', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
  }

  createDialog() {
    const dialog = document.createElement('dialog');
    dialog.className = 'task-dialog';
    dialog.setAttribute('aria-labelledby', 'task-dialog-title');
    dialog.innerHTML = `
      <div class="task-dialog__surface">
        <header class="task-dialog__header">
          <div>
            <p class="eyebrow">TASK PARAMETERS / LOCAL</p>
            <h2 id="task-dialog-title">Новая задача</h2>
          </div>
          <button class="icon-button" type="button" data-action="close-task-dialog" aria-label="Закрыть окно"><i data-lucide="x" aria-hidden="true"></i></button>
        </header>
        <form class="task-form" novalidate>
          <input type="hidden" name="taskId" />
          <label class="field-label" for="task-title">Название задачи</label>
          <input class="field-input" id="task-title" name="title" maxlength="120" autocomplete="off" required placeholder="Что нужно сделать?" />
          <label class="field-label field-label--spaced" for="task-description">Заметка</label>
          <textarea class="field-input task-textarea" id="task-description" name="description" maxlength="800" placeholder="Контекст, детали или следующий шаг"></textarea>
          <div class="task-form__schedule">
            <div>
              <label class="field-label" for="task-date">Дата</label>
              <input class="field-input" id="task-date" name="dueDate" type="date" />
            </div>
            <div>
              <label class="field-label" for="task-time">Время</label>
              <input class="field-input" id="task-time" name="dueTime" type="time" />
            </div>
          </div>
          <div class="task-tag-picker" data-task-tag-picker>
            <label class="field-label" for="task-tag-trigger">Категория</label>
            <input type="hidden" name="tagId" />
            <button class="tag-select-trigger" id="task-tag-trigger" type="button" data-action="toggle-tag-select" aria-haspopup="listbox" aria-expanded="false">
              <span class="tag-select-trigger__value"><i class="tag-select-trigger__dot" aria-hidden="true"></i><span>Без категории</span></span>
              <i data-lucide="chevrons-up-down" aria-hidden="true"></i>
            </button>
            <div class="tag-select-menu" data-tag-select-menu role="listbox" hidden></div>
          </div>
          <p class="form-error" data-task-form-error role="alert" hidden></p>
          <footer class="task-dialog__footer">
            <button class="secondary-button" type="button" data-action="close-task-dialog">Отмена</button>
            <button class="primary-button" type="submit"><i data-lucide="check" aria-hidden="true"></i><span>Добавить задачу</span></button>
          </footer>
        </form>
      </div>
    `;
    this.dialog = dialog;
    document.body.append(dialog);
    dialog.addEventListener('click', this.onDialogClick);
    dialog.querySelector('form').addEventListener('submit', this.onFormSubmit);
  }

  openCreateModal(initial = {}) {
    const form = this.dialog.querySelector('form');
    form.reset();
    form.elements.taskId.value = '';
    form.elements.title.value = initial.title || '';
    form.elements.description.value = initial.description || '';
    form.elements.dueDate.value = initial.dueDate || '';
    form.elements.dueTime.value = initial.dueTime || '';
    form.elements.tagId.value = initial.tagId || '';
    this.dialog.querySelector('#task-dialog-title').textContent = 'Новая задача';
    this.dialog.querySelector('[type="submit"] span').textContent = 'Добавить задачу';
    this.clearFormError();
    this.renderTagSelector(initial.tagId || '');
    this.dialog.showModal();
    requestAnimationFrame(() => form.elements.title.focus());
    this.refreshIcons();
  }

  openEditModal(taskId) {
    const task = this.storage.getTaskById(taskId);
    if (!task) return this.notify('Задача больше не существует.', 'error');
    const form = this.dialog.querySelector('form');
    form.elements.taskId.value = task.id;
    form.elements.title.value = task.title;
    form.elements.description.value = task.description || '';
    form.elements.dueDate.value = task.dueDate || '';
    form.elements.dueTime.value = task.dueTime || '';
    form.elements.tagId.value = task.tagId || '';
    this.dialog.querySelector('#task-dialog-title').textContent = 'Изменить задачу';
    this.dialog.querySelector('[type="submit"] span').textContent = 'Сохранить изменения';
    this.clearFormError();
    this.renderTagSelector(task.tagId || '');
    this.dialog.showModal();
    requestAnimationFrame(() => form.elements.title.select());
    this.refreshIcons();
  }

  closeModal() {
    if (this.dialog?.open) this.dialog.close();
  }

  renderTagSelector(selectedId) {
    const form = this.dialog.querySelector('form');
    const trigger = this.dialog.querySelector('[data-action="toggle-tag-select"]');
    const menu = this.dialog.querySelector('[data-tag-select-menu]');
    const selected = this.tags.getTagById(selectedId);
    const color = selected?.color || '#6B7280';
    trigger.querySelector('.tag-select-trigger__dot').style.backgroundColor = color;
    trigger.querySelector('.tag-select-trigger__value span').textContent = selected?.name || 'Без категории';
    form.elements.tagId.value = selected?.id || '';
    trigger.setAttribute('aria-expanded', 'false');
    menu.hidden = true;
    menu.replaceChildren(this.createTagOption({ id: '', name: 'Без категории', color: '#6B7280' }, !selectedId));
    this.storage.getTags().forEach((tag) => menu.append(this.createTagOption(tag, tag.id === selectedId)));
  }

  createTagOption(tag, selected) {
    const option = document.createElement('button');
    option.type = 'button';
    option.className = 'tag-select-option';
    option.dataset.action = 'select-task-tag';
    option.dataset.tagId = tag.id;
    option.setAttribute('role', 'option');
    option.setAttribute('aria-selected', String(selected));
    option.innerHTML = '<i aria-hidden="true"></i><span></span><em></em>';
    option.querySelector('i').style.backgroundColor = tag.color;
    option.querySelector('span').textContent = tag.name;
    option.querySelector('em').innerHTML = selected ? '<i data-lucide="check" aria-hidden="true"></i>' : '';
    return option;
  }

  onQuickSubmit(event) {
    event.preventDefault();
    const input = this.root.querySelector('[data-todo-quick-input]');
    const title = input.value.trim();
    if (!title) {
      input.focus();
      this.notify('Введите название задачи или откройте расширенную форму.', 'info');
      return;
    }
    try {
      this.createTask({ title });
      input.value = '';
      input.focus();
    } catch (error) {
      this.notify(error.message || 'Не удалось создать задачу.', 'error');
    }
  }

  onRootClick(event) {
    const button = event.target.closest('[data-action], [data-filter]');
    if (!button) return;
    if (button.dataset.filter) return this.setFilter(button.dataset.filter);
    const taskId = button.closest('[data-task-id]')?.dataset.taskId;
    switch (button.dataset.action) {
      case 'open-create-task': this.openCreateModal(); break;
      case 'toggle-task': this.toggleTask(taskId); break;
      case 'edit-task': this.openEditModal(taskId); break;
      case 'delete-task': this.deleteTask(taskId); break;
      default: break;
    }
  }

  onDialogClick(event) {
    if (event.target === this.dialog) return this.closeModal();
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const action = button.dataset.action;
    if (action === 'close-task-dialog') return this.closeModal();
    if (action === 'toggle-tag-select') {
      const menu = this.dialog.querySelector('[data-tag-select-menu]');
      const nextState = menu.hidden;
      menu.hidden = !nextState;
      button.setAttribute('aria-expanded', String(nextState));
      return;
    }
    if (action === 'select-task-tag') {
      this.renderTagSelector(button.dataset.tagId || '');
      this.refreshIcons();
    }
  }

  onFormSubmit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const values = Object.fromEntries(new FormData(form));
    try {
      if (values.taskId) this.updateTask(values.taskId, values);
      else this.createTask(values);
      this.closeModal();
    } catch (error) {
      this.showFormError(error.message || 'Не удалось сохранить задачу.');
    }
  }

  showFormError(message) {
    const target = this.dialog.querySelector('[data-task-form-error]');
    target.textContent = message;
    target.hidden = false;
  }

  clearFormError() {
    const target = this.dialog.querySelector('[data-task-form-error]');
    target.textContent = '';
    target.hidden = true;
  }

  refreshIcons() {
    window.lucide?.createIcons({ attrs: { 'stroke-width': 1.75 } });
  }
}
