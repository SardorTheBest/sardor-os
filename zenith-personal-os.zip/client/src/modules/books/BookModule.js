/**
 * Design reminder — Deep-Space Instrument Panel:
 * preserve Book Detail hierarchy—large cover, emerald reading state, precise mono metrics, controlled violet AI affordance.
 */
const formatTime = (seconds) => {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
  const remainder = (seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${remainder}`;
};

export class BookModule {
  constructor({ storage, root, notify = () => {} }) {
    if (!storage || !root) throw new Error('BookModule requires StorageManager and a root element.');
    this.storage = storage;
    this.root = root;
    this.notify = notify;
    this.selectedBookId = null;
    this.elapsedSeconds = 0;
    this.timerId = null;
    this.unsubscribe = null;
    this.dialog = null;
    this.onRootClick = this.onRootClick.bind(this);
    this.onDialogClick = this.onDialogClick.bind(this);
    this.onPageFormSubmit = this.onPageFormSubmit.bind(this);
    this.onQuoteFormSubmit = this.onQuoteFormSubmit.bind(this);
  }

  mount() {
    this.root.addEventListener('click', this.onRootClick);
    this.unsubscribe = this.storage.subscribe(() => this.render());
    this.createSessionDialog();
    this.render();
  }

  destroy() {
    this.stopTimer();
    this.root.removeEventListener('click', this.onRootClick);
    this.dialog?.removeEventListener('click', this.onDialogClick);
    this.dialog?.remove();
    this.unsubscribe?.();
  }

  get selectedBook() {
    const books = this.storage.getBooks();
    const preferred = books.find((book) => book.id === this.selectedBookId) || books.find((book) => book.status === 'reading') || books[0];
    this.selectedBookId = preferred?.id || null;
    return preferred || null;
  }

  render() {
    const book = this.selectedBook;
    if (!book) {
      this.root.innerHTML = '<section class="empty-book-state panel"><p class="eyebrow">READING / LOCAL</p><h2>В библиотеке пока нет книги.</h2></section>';
      return;
    }
    const percent = Math.round((book.readPages / book.totalPages) * 100);
    this.root.innerHTML = `
      <section class="book-page" aria-labelledby="book-title">
        <header class="book-topline"><button type="button" data-action="back-dashboard"><i data-lucide="arrow-left" aria-hidden="true"></i> К ДАШБОРДУ</button><p class="eyebrow">READING / LOCAL LIBRARY</p></header>
        <section class="book-hero panel">
          <div class="book-cover book-cover--${book.coverTone}" aria-hidden="true"><span>ZENITH<br>LIBRARY</span><strong></strong><em>${book.title}</em><small>${book.author}</small></div>
          <div class="book-identity"><p class="eyebrow">CURRENTLY READING</p><h2 id="book-title"></h2><p class="book-author"></p><div class="book-badges"><span>${book.genre}</span><span>${book.status === 'completed' ? 'ПРОЧИТАНО' : book.status === 'planned' ? 'В ПЛАНАХ' : 'ЧИТАЮ'}</span><span>${percent}%</span></div><p class="book-description">Личный контур чтения: прогресс, фокус-сессии, цитаты и заметки хранятся локально.</p></div>
          <section class="reading-timer" aria-label="Таймер чтения"><p class="eyebrow">READING SESSION</p><strong data-timer-value>${formatTime(this.elapsedSeconds)}</strong><span>${this.timerId ? 'Сессия активна' : 'Сессия ожидает'}</span><div class="timer-actions"><button type="button" data-action="start-timer"><i data-lucide="play" aria-hidden="true"></i>Старт</button><button type="button" data-action="pause-timer"><i data-lucide="pause" aria-hidden="true"></i>Пауза</button><button type="button" data-action="stop-timer"><i data-lucide="square" aria-hidden="true"></i>Стоп</button></div></section>
        </section>
        <section class="book-progress panel"><div class="book-progress__label"><p class="eyebrow">PROGRESS</p><strong>${percent}%</strong></div><div class="book-progress__track"><i style="width:${percent}%"></i></div><div class="book-progress__scale"><span>Стр. 1</span><b>Страница <em>${book.readPages}</em> из ${book.totalPages}</b><span>Стр. ${book.totalPages}</span></div></section>
        <div class="book-detail-grid"><section class="quote-panel panel" aria-labelledby="quotes-title"><div class="panel-heading compact-heading"><div><p class="eyebrow">NOTES & QUOTES</p><h3 id="quotes-title">Цитаты и заметки</h3></div><span class="violet-readout">LOCAL</span></div><form class="quote-form" data-quote-form><label class="sr-only" for="quote-input">Добавить цитату</label><textarea id="quote-input" name="quote" maxlength="600" placeholder="Сохранить мысль из этой книги"></textarea><button type="submit"><i data-lucide="plus" aria-hidden="true"></i>Добавить цитату</button></form><div class="quote-stack" data-quote-list></div></section><aside class="book-insights panel"><p class="eyebrow">READING SIGNAL</p><h3>Продолжайте спокойно.</h3><p>Короткие регулярные сессии сохраняют ритм лучше, чем редкие длинные марафоны.</p><div><span>ГОТОВО</span><strong>${book.readPages} / ${book.totalPages}</strong></div></aside></div>
      </section>
    `;
    this.root.querySelector('#book-title').textContent = book.title;
    this.root.querySelector('.book-author').textContent = book.author;
    const quoteList = this.root.querySelector('[data-quote-list]');
    if (!book.quotes.length) quoteList.innerHTML = '<p class="quote-empty">Первая важная мысль из книги появится здесь.</p>';
    book.quotes.slice().reverse().forEach((quote) => {
      const article = document.createElement('blockquote');
      article.className = 'quote-card';
      article.textContent = `«${quote.content}»`;
      quoteList.append(article);
    });
    this.root.querySelector('[data-quote-form]').addEventListener('submit', this.onQuoteFormSubmit);
    this.refreshIcons();
  }

  startTimer() {
    if (this.timerId) return;
    this.timerId = window.setInterval(() => {
      this.elapsedSeconds += 1;
      const output = this.root.querySelector('[data-timer-value]');
      if (output) output.textContent = formatTime(this.elapsedSeconds);
    }, 1000);
    this.render();
  }

  pauseTimer() {
    if (!this.timerId) return;
    window.clearInterval(this.timerId);
    this.timerId = null;
    this.render();
  }

  stopTimer() {
    if (!this.timerId && this.elapsedSeconds === 0) return;
    window.clearInterval(this.timerId);
    this.timerId = null;
    if (this.elapsedSeconds > 0) this.openSessionDialog();
    else this.render();
  }

  createSessionDialog() {
    const dialog = document.createElement('dialog');
    dialog.className = 'reading-session-dialog';
    dialog.innerHTML = `
      <div class="task-dialog__surface"><header class="task-dialog__header"><div><p class="eyebrow">SESSION COMPLETE</p><h2>Сколько страниц вы прочитали?</h2></div><button class="icon-button" type="button" data-action="close-pages-dialog" aria-label="Закрыть"><i data-lucide="x" aria-hidden="true"></i></button></header><form data-pages-form class="pages-form"><p>Сессия длилась <strong data-session-duration>00:00</strong>. Укажите только количество страниц за эту сессию.</p><label class="field-label" for="pages-read">Прочитано страниц</label><input class="field-input" id="pages-read" name="pages" type="number" min="1" step="1" required inputmode="numeric" placeholder="Например, 12"><p class="form-error" data-pages-error role="alert" hidden></p><footer class="task-dialog__footer"><button class="secondary-button" type="button" data-action="close-pages-dialog">Пропустить</button><button class="primary-button" type="submit"><i data-lucide="book-open-check" aria-hidden="true"></i>Сохранить прогресс</button></footer></form></div>
    `;
    this.dialog = dialog;
    document.body.append(dialog);
    dialog.addEventListener('click', this.onDialogClick);
    dialog.querySelector('form').addEventListener('submit', this.onPageFormSubmit);
  }

  openSessionDialog() {
    this.dialog.querySelector('[data-session-duration]').textContent = formatTime(this.elapsedSeconds);
    this.dialog.querySelector('[data-pages-error]').hidden = true;
    this.dialog.querySelector('form').reset();
    this.dialog.showModal();
    requestAnimationFrame(() => this.dialog.querySelector('[name="pages"]').focus());
    this.refreshIcons();
  }

  closeSessionDialog() {
    if (this.dialog?.open) this.dialog.close();
    this.elapsedSeconds = 0;
    this.render();
  }

  onRootClick(event) {
    if (event.target.closest('[data-quote-form]')) return;
    const action = event.target.closest('[data-action]')?.dataset.action;
    if (!action) return;
    if (action === 'start-timer') this.startTimer();
    if (action === 'pause-timer') this.pauseTimer();
    if (action === 'stop-timer') this.stopTimer();
    if (action === 'back-dashboard') window.dispatchEvent(new CustomEvent('zenith:navigate', { detail: 'dashboard' }));
  }

  onDialogClick(event) {
    if (event.target === this.dialog || event.target.closest('[data-action="close-pages-dialog"]')) this.closeSessionDialog();
  }

  onPageFormSubmit(event) {
    event.preventDefault();
    const pages = Number(new FormData(event.currentTarget).get('pages'));
    const error = this.dialog.querySelector('[data-pages-error]');
    try {
      const book = this.storage.addReadPages(this.selectedBookId, pages);
      this.notify(book.status === 'completed' ? 'Книга отмечена как прочитанная.' : 'Прогресс чтения сохранён локально.', 'success');
      this.closeSessionDialog();
    } catch (exception) {
      error.textContent = exception.message;
      error.hidden = false;
    }
  }

  onQuoteFormSubmit(event) {
    event.preventDefault();
    const content = new FormData(event.currentTarget).get('quote');
    try {
      this.storage.addBookQuote(this.selectedBookId, content);
      this.notify('Цитата добавлена в локальную библиотеку.', 'success');
    } catch (exception) {
      this.notify(exception.message, 'error');
    }
  }

  refreshIcons() {
    window.lucide?.createIcons({ attrs: { 'stroke-width': 1.75 } });
  }
}
