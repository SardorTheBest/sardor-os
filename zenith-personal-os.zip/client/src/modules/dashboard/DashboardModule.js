/**
 * Design reminder — Deep-Space Instrument Panel:
 * the dashboard follows the supplied Today Overview: main focus, pomodoro-like focus signal, habits and currently-reading cards.
 */
const dateKey = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
};

export class DashboardModule {
  constructor({ storage, root, notify = () => {} }) {
    if (!storage || !root) throw new Error('DashboardModule requires StorageManager and a root element.');
    this.storage = storage;
    this.root = root;
    this.notify = notify;
    this.unsubscribe = null;
    this.onRootClick = this.onRootClick.bind(this);
  }

  mount() {
    this.root.addEventListener('click', this.onRootClick);
    this.unsubscribe = this.storage.subscribe(() => this.render());
    this.render();
  }

  destroy() {
    this.root.removeEventListener('click', this.onRootClick);
    this.unsubscribe?.();
  }

  render() {
    const user = this.storage.getUser();
    const today = dateKey();
    const tasks = this.storage.getTasks();
    const focusTasks = tasks.filter((task) => !task.isCompleted && (task.dueDate === today || !task.dueDate)).slice(0, 3);
    const habits = this.storage.getHabits().slice(0, 3);
    const habitStats = this.storage.getHabitStats(today);
    const book = this.storage.getBooks().find((item) => item.status === 'reading') || this.storage.getBooks()[0];
    const greeting = new Date().getHours() < 12 ? 'Доброе утро' : new Date().getHours() < 18 ? 'Добрый день' : 'Добрый вечер';
    const calendarLabel = new Intl.DateTimeFormat('ru-RU', { weekday: 'long', day: 'numeric', month: 'long' })
      .format(new Date())
      .replace(/^./, (letter) => letter.toUpperCase());
    this.root.innerHTML = `
      <section class="today-overview" aria-labelledby="today-title">
        <header class="today-overview__intro"><p class="eyebrow">FOCUS MODE / LOCAL</p><h2 id="today-title">${greeting}, ${user.name}.</h2><p>Здесь ваш высокий уровень обзора на сегодня.</p></header>
        <div class="overview-grid">
          <section class="main-focus-card panel"><div class="main-focus-card__heading"><p class="eyebrow">◎ MAIN FOCUS / DAILY TO-DO</p><span>${focusTasks.filter((task) => task.isCompleted).length}/${focusTasks.length || 0} COMPLETED</span></div><div class="focus-task-stack" data-dashboard-tasks></div><div class="focus-status-matrix" data-focus-status-matrix><div><span>QUEUE</span><strong>${focusTasks.length ? `${focusTasks.length} ACTIVE` : 'CLEAR'}</strong></div><div><span>FOCUS MODE</span><strong>STANDBY</strong></div><div><span>NEXT STEP</span><strong>${focusTasks.length ? 'EXECUTE' : 'DEFINE'}</strong></div></div><div class="focus-ledger"><div><span>DAY SIGNAL</span><strong>${calendarLabel}</strong></div><div><span>LOCAL MEMORY</span><strong>READY</strong></div><div><span>OPEN TASKS</span><strong>${String(focusTasks.length).padStart(2, '0')}</strong></div><button type="button" data-action="open-tasks">Добавить главную задачу <i data-lucide="arrow-up-right" aria-hidden="true"></i></button></div></section>
          <aside class="overview-side"><section class="temporal-card panel"><div><p class="eyebrow">TEMPORAL OVERVIEW</p><h3>${calendarLabel}</h3></div><div class="temporal-days"><span>ПН</span><span>ВТ</span><span>СР</span><span>ЧТ</span><span>ПТ</span><span>СБ</span><span>ВС</span></div><button type="button" data-action="open-tasks"><i data-lucide="calendar-days" aria-hidden="true"></i> Открыть календарный обзор</button></section><section class="pomodoro-card panel"><p class="eyebrow">◉ FOCUS SIGNAL</p><strong>25:00</strong><span>Session 1 / 4</span><button type="button" data-action="open-tasks">Открыть задачи</button></section></aside>
          <section class="dashboard-habits panel"><div class="panel-heading compact-heading"><div><p class="eyebrow">DAILY HABITS</p><h3>Сегодняшний ритм</h3></div><b>${habitStats.completed}/${habitStats.total}</b></div><div class="dashboard-habit-list" data-dashboard-habits></div><div class="progress-track"><i style="width:${habitStats.percent}%"></i></div></section>
          <section class="dashboard-book panel"><p class="eyebrow">CURRENTLY READING</p><div data-dashboard-book></div></section>
        </div>
      </section>
    `;
    const taskContainer = this.root.querySelector('[data-dashboard-tasks]');
    if (!focusTasks.length) taskContainer.innerHTML = '<p class="overview-empty">Контур свободен. Зафиксируйте один осознанный фокус, прежде чем добавлять остальное.</p>';
    focusTasks.forEach((task) => {
      const row = document.createElement('button');
      row.type = 'button';
      row.className = 'overview-task';
      row.dataset.action = 'open-tasks';
      row.innerHTML = '<i data-lucide="circle" aria-hidden="true"></i><span></span>';
      row.querySelector('span').textContent = task.title;
      taskContainer.append(row);
    });
    const habitContainer = this.root.querySelector('[data-dashboard-habits]');
    habits.forEach((habit) => {
      const checked = Boolean(habit.history?.[today]);
      const row = document.createElement('button');
      row.type = 'button';
      row.className = `dashboard-habit${checked ? ' is-completed' : ''}`;
      row.dataset.habitId = habit.id;
      row.dataset.action = 'dashboard-toggle-habit';
      row.innerHTML = '<i data-lucide="check" aria-hidden="true"></i><span></span><em></em>';
      row.querySelector('span').textContent = habit.title;
      row.querySelector('em').textContent = `${habit.streak || 0} DAYS`;
      habitContainer.append(row);
    });
    const bookContainer = this.root.querySelector('[data-dashboard-book]');
    if (book) {
      const percent = Math.round((book.readPages / book.totalPages) * 100);
      bookContainer.innerHTML = `<button type="button" data-action="open-books" class="dashboard-book__item"><div class="tiny-cover tiny-cover--${book.coverTone}"></div><div><h3></h3><p></p><strong>${percent}%</strong><div class="progress-track"><i style="width:${percent}%"></i></div></div></button>`;
      bookContainer.querySelector('h3').textContent = book.title;
      bookContainer.querySelector('p').textContent = book.author;
    } else bookContainer.innerHTML = '<p class="overview-empty">Добавьте книгу в библиотеку.</p>';
    this.refreshIcons();
  }

  onRootClick(event) {
    const target = event.target.closest('[data-action]');
    if (!target) return;
    if (target.dataset.action === 'dashboard-toggle-habit') {
      const habit = this.storage.toggleHabit(target.dataset.habitId);
      this.notify(habit.history?.[dateKey()] ? 'Привычка отмечена на дашборде.' : 'Отметка привычки снята.', 'success');
      return;
    }
    if (target.dataset.action === 'open-tasks') window.dispatchEvent(new CustomEvent('zenith:navigate', { detail: 'tasks' }));
    if (target.dataset.action === 'open-books') window.dispatchEvent(new CustomEvent('zenith:navigate', { detail: 'books' }));
  }

  refreshIcons() {
    window.lucide?.createIcons({ attrs: { 'stroke-width': 1.75 } });
  }
}
