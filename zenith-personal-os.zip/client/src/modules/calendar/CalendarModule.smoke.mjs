/** Run with: node client/src/modules/calendar/CalendarModule.smoke.mjs */
const { buildMonthGrid, dateToKey, groupScheduledTasks } = await import('./CalendarModule.js');

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const february2024 = buildMonthGrid(new Date(2024, 1, 15));
assert(february2024.length === 35, 'Февраль 2024 должен занять пять недель в сетке.');
assert(february2024.some((item) => item.dateKey === '2024-02-29'), 'Високосный день 29 февраля должен присутствовать.');
assert(february2024[0].dateKey === '2024-01-29', 'Сетка должна начинаться с понедельника предыдущего месяца.');

const september2024 = buildMonthGrid(new Date(2024, 8, 1));
assert(september2024[0].dateKey === '2024-08-26', 'Месяц, начинающийся в воскресенье, должен иметь шесть лидирующих ячеек.');
assert(september2024.every((item, index) => index === 0 || dateToKey(item.date) > dateToKey(september2024[index - 1].date)), 'Дата каждой ячейки должна возрастать.');

const grouped = groupScheduledTasks([
  { id: 'early', title: 'Ранний слот', dueDate: '2026-08-27', dueTime: '09:00' },
  { id: 'later', title: 'Поздний слот', dueDate: '2026-08-27', dueTime: '14:00' },
  { id: 'untimed', title: 'Без времени', dueDate: '2026-08-27', dueTime: null },
  { id: 'invalid', title: 'Некорректная дата', dueDate: '2026-02-31', dueTime: '10:00' },
]);
assert(grouped.get('2026-08-27')?.length === 2, 'В календарь должны попадать только задачи с валидной датой и временем.');
assert(!grouped.has('2026-02-31'), 'Невозможная дата не должна попасть в календарь.');

console.log('CalendarModule smoke test passed.');
