/**
 * Sprint 3 calendar controller. It renders views only and delegates every
 * persistence action to the existing StorageManager, TodoModule, and TagManager.
 */
const WEEKDAY_LABELS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
const VIEW_MODES = new Set(['month', 'week', 'day']);
const FALLBACK_TAG_COLOR = '#62626A';

function startOfDay(value = new Date()) {
  return new Date(value.getFullYear(), value.getMonth(), value.getDate());
}

export function dateToKey(value) {
  const date = startOfDay(value);
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export function dateFromKey(key) {
  const [year, month, day] = String(key || '').split('-').map(Number);
  if (!year || !month || !day) return null;
  const date = new Date(year, month - 1, day);
  return dateToKey(date) === key ? date : null;
}

function mondayIndex(date) {
  return (date.getDay() + 6) % 7;
}

function addDays(date, amount) {
  const next = startOfDay(date);
  next.setDate(next.getDate() + amount);
  return next;
}

function capitalize(value) {
  return value ? `${value[0].toUpperCase()}${value.slice(1)}` : value;
}

function formatDate(date, options) {
  return new Intl.DateTimeFormat('ru-RU', options).format(date);
}

export function formatMonthTitle(date) {
  return capitalize(formatDate(date, { month: 'long', year: 'numeric' }));
}

/** Builds a Monday-first grid with leading and trailing days included. */
export function buildMonthGrid(viewDate) {
  const anchor = startOfDay(viewDate);
  const monthStart = new Date(anchor.getFullYear(), anchor.getMonth(), 1);
  const leadingDays = mondayIndex(monthStart);
  const daysInMonth = new Date(anchor.getFullYear(), anchor.getMonth() + 1, 0).getDate();
  const cells = Math.max(35, Math.ceil((leadingDays + daysInMonth) / 7) * 7);
  const gridStart = addDays(monthStart, -leadingDays);
  const todayKey = dateToKey();

  return Array.from({ length: cells }, (_, index) => {
    const date = addDays(gridStart, index);
    return {
      date,
      dateKey: dateToKey(date),
      day: date.getDate(),
      isCurrentMonth: date.getMonth() === anchor.getMonth(),
      isToday: dateToKey(date) === todayKey,
    };
  });
}

/** Selects only scheduled tasks with valid date keys and groups them by date. */
export function groupScheduledTasks(tasks = []) {
  return tasks
    .filter((task) => task?.dueDate && task?.dueTime && dateFromKey(task.dueDate))
    .reduce((groups, task) => {
      const list = groups.get(task.dueDate) || [];
      list.push(task);
      groups.set(task.dueDate, list);
      return groups;
    }, new Map());
}

function sortScheduledTasks(tasks) {
  return [...tasks].sort((left, right) => (
    String(left.dueTime).localeCompare(String(right.dueTime))
      || String(left.createdAt || '').localeCompare(String(right.createdAt || ''))
      || String(left.title || '').localeCompare(String(right.title || ''))
  ));
}

function icon(name) {
  return `<i data-lucide="${name}" aria-hidden="true"></i>`;
}

export class CalendarModule {
  constructor({ storage, tags, todo, root }) {
    if (!storage) throw new Error('CalendarModule requires StorageManager.');
    if (!tags) throw new Error('CalendarModule requires TagManager.');
    if (!todo) throw new Error('CalendarModule requires TodoModule.');
    if (!root) throw new Error('CalendarModule requires a root element.');

    this.storage = storage;
    this.tags = tags;
    this.todo = todo;
    this.root = root;
    this.viewDate = startOfDay();
    this.mode = 'month';
    this.expandedDates = new Set();
    this.unsubscribe = null;
    this.staticControls = [];
    this.onRootClick = this.onRootClick.bind(this);
    this.onRootKeyDown = this.onRootKeyDown.bind(this);
    this.onStaticControlClick = this.onStaticControlClick.bind(this);
  }

  mount() {
    this.root.addEventListener('click', this.onRootClick);
    this.root.addEventListener('keydown', this.onRootKeyDown);
    this.staticControls = [...this.root.querySelectorAll('[data-calendar-action="previous"], [data-calendar-action="next"], [data-calendar-action="today"], [data-calendar-action="manage-tags"]')];
    this.staticControls.forEach((control) => control.addEventListener('click', this.onStaticControlClick));
    this.unsubscribe = this.storage.subscribe(() => this.render());
    this.render();
  }

  destroy() {
    this.root.removeEventListener('click', this.onRootClick);
    this.root.removeEventListener('keydown', this.onRootKeyDown);
    this.staticControls.forEach((control) => control.removeEventListener('click', this.onStaticControlClick));
    this.unsubscribe?.();
  }

  focus() {
    this.setMode('month');
    this.root.scrollIntoView({ behavior: 'smooth', block: 'start' });
    this.root.querySelector('[data-calendar-today]')?.focus();
  }

  setMode(mode) {
    if (!VIEW_MODES.has(mode)) return;
    this.mode = mode;
    this.expandedDates.clear();
    this.render();
  }

  shiftPeriod(amount) {
    const next = startOfDay(this.viewDate);
    if (this.mode === 'month') next.setMonth(next.getMonth() + amount, 1);
    if (this.mode === 'week') next.setDate(next.getDate() + amount * 7);
    if (this.mode === 'day') next.setDate(next.getDate() + amount);
    this.viewDate = next;
    this.expandedDates.clear();
    this.render();
  }

  goToday() {
    this.viewDate = startOfDay();
    this.expandedDates.clear();
    this.render();
  }

  getTaskGroups() {
    const groups = groupScheduledTasks(this.storage.getTasks());
    groups.forEach((tasks, key) => groups.set(key, sortScheduledTasks(tasks)));
    return groups;
  }

  getPeriodTitle() {
    if (this.mode === 'month') return formatMonthTitle(this.viewDate);
    if (this.mode === 'day') return capitalize(formatDate(this.viewDate, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }));

    const start = addDays(this.viewDate, -mondayIndex(this.viewDate));
    const end = addDays(start, 6);
    const sameMonth = start.getMonth() === end.getMonth() && start.getFullYear() === end.getFullYear();
    const startLabel = formatDate(start, sameMonth ? { day: 'numeric' } : { day: 'numeric', month: 'short' });
    return `${startLabel} — ${formatDate(end, { day: 'numeric', month: 'long', year: 'numeric' })}`;
  }

  getVisibleTaskCount(groups) {
    if (this.mode === 'day') return groups.get(dateToKey(this.viewDate))?.length || 0;
    if (this.mode === 'week') {
      const start = addDays(this.viewDate, -mondayIndex(this.viewDate));
      return Array.from({ length: 7 }, (_, index) => groups.get(dateToKey(addDays(start, index)))?.length || 0)
        .reduce((total, count) => total + count, 0);
    }
    return buildMonthGrid(this.viewDate)
      .filter((item) => item.isCurrentMonth)
      .reduce((total, item) => total + (groups.get(item.dateKey)?.length || 0), 0);
  }

  render() {
    const groups = this.getTaskGroups();
    const total = this.getVisibleTaskCount(groups);
    this.root.dataset.calendarMode = this.mode;
    this.root.querySelector('[data-calendar-title]').textContent = this.getPeriodTitle();
    this.root.querySelector('[data-current-day]').textContent = String(this.viewDate.getDate()).padStart(2, '0');
    this.root.querySelector('[data-month-days]').textContent = String(new Date(this.viewDate.getFullYear(), this.viewDate.getMonth() + 1, 0).getDate()).padStart(2, '0');
    this.root.querySelector('[data-calendar-focus]').textContent = total ? `${String(total).padStart(2, '0')} PLANNED` : 'STANDBY';
    this.root.querySelector('[data-calendar-footer-note]').textContent = total ? `В выбранном периоде: ${total} заплан. ${total === 1 ? 'задача' : 'задач'}.` : 'Запланированные задачи появятся здесь после первой записи.';
    this.root.querySelectorAll('[data-calendar-mode]').forEach((button) => {
      const active = button.dataset.calendarMode === this.mode;
      button.classList.toggle('calendar-view-button--active', active);
      button.setAttribute('aria-pressed', String(active));
    });

    const view = this.root.querySelector('[data-calendar-view]');
    view.replaceChildren();
    if (this.mode === 'month') this.renderMonth(view, groups);
    if (this.mode === 'week') this.renderWeek(view, groups);
    if (this.mode === 'day') this.renderDay(view, groups);
    this.refreshIcons();
  }

  renderMonth(target, groups) {
    const labels = document.createElement('div');
    labels.className = 'weekday-row';
    labels.setAttribute('aria-hidden', 'true');
    WEEKDAY_LABELS.forEach((label) => {
      const item = document.createElement('span');
      item.textContent = label;
      labels.append(item);
    });

    const grid = document.createElement('div');
    grid.className = 'calendar-grid calendar-grid--month';
    grid.setAttribute('role', 'grid');
    grid.setAttribute('aria-label', `Календарь: ${this.getPeriodTitle()}`);
    buildMonthGrid(this.viewDate).forEach((day) => grid.append(this.createMonthCell(day, groups.get(day.dateKey) || [])));
    target.append(labels, grid);
  }

  createMonthCell(day, tasks) {
    const cell = document.createElement('div');
    cell.className = `calendar-day-cell${day.isCurrentMonth ? '' : ' calendar-day-cell--muted'}${day.isToday ? ' calendar-day-cell--today' : ''}`;
    cell.dataset.calendarDate = day.dateKey;
    cell.tabIndex = 0;
    cell.setAttribute('role', 'gridcell');
    cell.setAttribute('aria-label', `${formatDate(day.date, { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}. Нажмите Enter, чтобы создать задачу.`);
    cell.addEventListener('click', (event) => {
      if (event.target.closest('[data-calendar-task-id], [data-calendar-action]')) return;
      event.stopPropagation();
      this.openCreate(day.dateKey);
    });

    const dateButton = document.createElement('button');
    dateButton.type = 'button';
    dateButton.className = 'calendar-day-number';
    dateButton.dataset.calendarAction = 'create-task';
    dateButton.dataset.calendarDate = day.dateKey;
    dateButton.setAttribute('aria-label', `Создать задачу на ${formatDate(day.date, { day: 'numeric', month: 'long' })}`);
    dateButton.textContent = String(day.day);
    cell.append(dateButton);
    this.appendTaskPills(cell, tasks, day.dateKey);
    return cell;
  }

  appendTaskPills(container, tasks, dateKey) {
    if (!tasks.length) return;
    const expanded = this.expandedDates.has(dateKey);
    const list = document.createElement('div');
    list.className = 'calendar-task-list';
    (expanded ? tasks : tasks.slice(0, 3)).forEach((task) => list.append(this.createTaskPill(task)));
    container.append(list);

    if (tasks.length > 3) {
      const overflow = document.createElement('button');
      overflow.type = 'button';
      overflow.className = 'calendar-overflow-button';
      overflow.dataset.calendarAction = 'toggle-overflow';
      overflow.dataset.calendarDate = dateKey;
      overflow.setAttribute('aria-expanded', String(expanded));
      overflow.textContent = expanded ? 'Свернуть' : `+ ${tasks.length - 3} ещё`;
      container.append(overflow);
    }
  }

  createTaskPill(task) {
    const pill = document.createElement('button');
    const color = this.tags.getColorByTagId(task.tagId) || FALLBACK_TAG_COLOR;
    pill.type = 'button';
    pill.className = `calendar-task-pill${task.isCompleted ? ' calendar-task-pill--completed' : ''}`;
    pill.dataset.calendarTaskId = task.id;
    pill.style.setProperty('--calendar-tag-color', color);
    pill.title = `${task.dueTime} — ${task.title}`;
    pill.setAttribute('aria-label', `Открыть задачу: ${task.title}, ${task.dueTime}`);
    pill.innerHTML = '<span class="calendar-task-pill__time"></span><span class="calendar-task-pill__title"></span>';
    pill.querySelector('.calendar-task-pill__time').textContent = task.dueTime;
    pill.querySelector('.calendar-task-pill__title').textContent = task.title;
    return pill;
  }

  renderWeek(target, groups) {
    const start = addDays(this.viewDate, -mondayIndex(this.viewDate));
    const grid = document.createElement('div');
    grid.className = 'calendar-week-grid';
    grid.setAttribute('role', 'grid');
    grid.setAttribute('aria-label', `Неделя: ${this.getPeriodTitle()}`);
    Array.from({ length: 7 }, (_, index) => addDays(start, index)).forEach((date) => {
      const key = dateToKey(date);
      const column = document.createElement('div');
      column.className = `calendar-week-day${key === dateToKey() ? ' calendar-week-day--today' : ''}`;
      column.dataset.calendarDate = key;
      column.tabIndex = 0;
      column.setAttribute('role', 'gridcell');
      column.setAttribute('aria-label', `${formatDate(date, { weekday: 'long', day: 'numeric', month: 'long' })}. Нажмите Enter, чтобы создать задачу.`);
      const heading = document.createElement('button');
      heading.type = 'button';
      heading.className = 'calendar-week-day__heading';
      heading.dataset.calendarAction = 'create-task';
      heading.dataset.calendarDate = key;
      heading.innerHTML = '<span></span><strong></strong>';
      heading.querySelector('span').textContent = capitalize(formatDate(date, { weekday: 'short' }).replace('.', ''));
      heading.querySelector('strong').textContent = String(date.getDate()).padStart(2, '0');
      column.append(heading);
      this.appendTaskPills(column, groups.get(key) || [], key);
      grid.append(column);
    });
    target.append(grid);
  }

  renderDay(target, groups) {
    const key = dateToKey(this.viewDate);
    const tasks = groups.get(key) || [];
    const agenda = document.createElement('section');
    agenda.className = 'calendar-day-agenda';
    agenda.setAttribute('aria-label', `Расписание на ${formatDate(this.viewDate, { day: 'numeric', month: 'long' })}`);
    const addButton = document.createElement('button');
    addButton.type = 'button';
    addButton.className = 'calendar-day-agenda__add';
    addButton.dataset.calendarAction = 'create-task';
    addButton.dataset.calendarDate = key;
    addButton.innerHTML = `${icon('plus')}<span>Добавить задачу на этот день</span>`;
    agenda.append(addButton);

    if (!tasks.length) {
      const empty = document.createElement('div');
      empty.className = 'calendar-agenda-empty';
      empty.innerHTML = `${icon('calendar-plus')}<p>В этот день пока нет задач с указанным временем.</p>`;
      agenda.append(empty);
    } else {
      const list = document.createElement('div');
      list.className = 'calendar-agenda-list';
      tasks.forEach((task) => list.append(this.createAgendaItem(task)));
      agenda.append(list);
    }
    target.append(agenda);
  }

  createAgendaItem(task) {
    const item = document.createElement('button');
    const color = this.tags.getColorByTagId(task.tagId) || FALLBACK_TAG_COLOR;
    item.type = 'button';
    item.className = `calendar-agenda-item${task.isCompleted ? ' calendar-agenda-item--completed' : ''}`;
    item.dataset.calendarTaskId = task.id;
    item.style.setProperty('--calendar-tag-color', color);
    item.innerHTML = '<time></time><span class="calendar-agenda-item__signal" aria-hidden="true"></span><span class="calendar-agenda-item__content"><strong></strong><small></small></span><span class="calendar-agenda-item__edit" aria-hidden="true"></span>';
    item.querySelector('time').textContent = task.dueTime;
    item.querySelector('.calendar-agenda-item__content strong').textContent = task.title;
    item.querySelector('.calendar-agenda-item__content small').textContent = task.description || this.tags.getTagById(task.tagId)?.name || 'Без заметки';
    item.querySelector('.calendar-agenda-item__edit').innerHTML = icon('arrow-up-right');
    item.setAttribute('aria-label', `Открыть задачу: ${task.title}, ${task.dueTime}`);
    return item;
  }

  openCreate(dateKey) {
    const date = dateFromKey(dateKey);
    if (!date) return;
    this.viewDate = date;
    this.todo.openCreateModal({ dueDate: dateKey });
  }

  performAction(action, calendarDate) {
    if (action === 'previous') this.shiftPeriod(-1);
    if (action === 'next') this.shiftPeriod(1);
    if (action === 'today') this.goToday();
    if (action === 'create-task') this.openCreate(calendarDate);
    if (action === 'manage-tags') this.tags.openCreateModal();
    if (action === 'toggle-overflow') {
      if (this.expandedDates.has(calendarDate)) this.expandedDates.delete(calendarDate);
      else this.expandedDates.add(calendarDate);
      this.render();
    }
  }

  onStaticControlClick(event) {
    event.stopPropagation();
    this.performAction(event.currentTarget.dataset.calendarAction);
  }

  onRootClick(event) {
    const task = event.target.closest('[data-calendar-task-id]');
    if (task) {
      event.stopPropagation();
      this.todo.openEditModal(task.dataset.calendarTaskId);
      return;
    }
    const modeButton = event.target.closest('[data-calendar-mode]');
    if (modeButton) {
      this.setMode(modeButton.dataset.calendarMode);
      return;
    }
    const trigger = event.target.closest('[data-calendar-action]');
    if (trigger) {
      const { calendarAction: action, calendarDate } = trigger.dataset;
      this.performAction(action, calendarDate);
      return;
    }
    const cell = event.target.closest('[data-calendar-date]');
    if (cell) this.openCreate(cell.dataset.calendarDate);
  }

  onRootKeyDown(event) {
    const cell = event.target.closest('[data-calendar-date]');
    if (!cell || event.target !== cell || !['Enter', ' '].includes(event.key)) return;
    event.preventDefault();
    this.openCreate(cell.dataset.calendarDate);
  }

  refreshIcons() {
    window.lucide?.createIcons({ attrs: { 'stroke-width': 1.75 } });
  }
}
