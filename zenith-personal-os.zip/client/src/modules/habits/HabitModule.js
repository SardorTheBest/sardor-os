/**
 * Design reminder — Deep-Space Instrument Panel:
 * render Space Contrast discipline data as compact emerald signals, violet secondary readouts and low-noise ledger surfaces.
 */
const FILTERS = new Set(['all', 'health', 'learning', 'focus']);
const DAY_MS = 86_400_000;

const localDateKey = (date = new Date()) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const localDate = (dateKey) => {
  const [year, month, day] = dateKey.split('-').map(Number);
  return new Date(year, month - 1, day);
};

const dayLabel = (dateKey) => new Intl.DateTimeFormat('ru-RU', {
  day: 'numeric', month: 'long', year: 'numeric',
}).format(localDate(dateKey));

export class HabitModule {
  constructor({ storage, root, notify = () => {} }) {
    if (!storage || !root) throw new Error('HabitModule requires StorageManager and a root element.');
    this.storage = storage;
    this.root = root;
    this.notify = notify;
    this.filter = 'all';
    this.unsubscribe = null;
    this.onRootClick = this.onRootClick.bind(this);
  }

  mount() {
    this.root.addEventListener('click', this.onRootClick);
    this.unsubscribe = this.storage.subscribe(() => this.render());
    this.render();
  }

  destroy() {
    this.root.removeEventListener('click', this.onRootClick);
    this.unsubscribe?.();
  }

  getVisibleHabits() {
    return this.storage.getHabits().filter((habit) => this.filter === 'all' || habit.category === this.filter);
  }

  getDailyPercent(dateKey) {
    const habits = this.storage.getHabits();
    if (!habits.length) return 0;
    return Math.round((habits.filter((habit) => habit.history?.[dateKey]).length / habits.length) * 100);
  }

  getRecentDays(count = 364) {
    return Array.from({ length: count }, (_, index) => {
      const date = new Date();
      date.setDate(date.getDate() - (count - 1 - index));
      return localDateKey(date);
    });
  }

  render() {
    const stats = this.storage.getHabitStats();
    const visibleHabits = this.getVisibleHabits();
    this.root.innerHTML = `
      <section class="habit-page" aria-labelledby="habits-page-title">
        <header class="feature-header">
          <div><p class="eyebrow">RHYTHM / LOCAL DISCIPLINE</p><h2 id="habits-page-title">Ритм и дисциплина.</h2><p>Отмечайте привычки, наблюдайте за серией и сохраняйте инерцию.</p></div>
          <div class="feature-stat"><strong data-habit-active-days>00</strong><span>дней в ритме</span></div>
        </header>
        <section class="annual-discipline panel" aria-labelledby="heatmap-title">
          <div class="panel-heading compact-heading"><div><p class="eyebrow">ANNUAL DISCIPLINE</p><h3 id="heatmap-title">Тепловая карта активности</h3></div><span class="heatmap-legend"><i></i> Меньше <i></i><i></i><i></i> Больше</span></div>
          <div class="heatmap" data-heatmap aria-label="История активности за последние 84 дня"></div>
          <div class="heatmap-tooltip" data-heatmap-tooltip role="status">Выберите ячейку, чтобы увидеть сводку дня.</div>
        </section>
        <div class="habit-layout">
          <aside class="rhythm-summary panel">
            <p class="eyebrow">CURRENT RHYTHM</p>
            <div class="rhythm-number"><span data-longest-streak>0</span><small>дней</small></div>
            <p class="rhythm-label">Самая длинная серия</p>
            <div class="rhythm-progress"><div class="rhythm-progress__label"><span>Сегодня</span><b data-today-habit-percent>0%</b></div><div class="progress-track"><i data-today-habit-progress></i></div></div>
            <p class="discipline-quote">«Дисциплина — это свобода, которую видно в повторении.»</p>
          </aside>
          <section class="daily-habits panel" aria-labelledby="daily-habits-title">
            <div class="habit-toolbar"><div><p class="eyebrow">DAILY HABITS</p><h3 id="daily-habits-title">Ежедневный ритм</h3></div><div class="habit-filter-bar" role="group" aria-label="Фильтр привычек"><button type="button" data-habit-filter="all">Все</button><button type="button" data-habit-filter="health">Здоровье</button><button type="button" data-habit-filter="learning">Обучение</button><button type="button" data-habit-filter="focus">Фокус</button></div></div>
            <div class="habit-stack" data-habit-list></div>
            <p class="habit-empty" data-habit-empty hidden>В этой категории пока нет привычек.</p>
          </section>
        </div>
      </section>
    `;
    this.root.querySelector('[data-longest-streak]').textContent = stats.longestStreak;
    this.root.querySelector('[data-today-habit-percent]').textContent = `${stats.percent}%`;
    this.root.querySelector('[data-today-habit-progress]').style.width = `${stats.percent}%`;
    this.root.querySelector('[data-habit-active-days]').textContent = String(this.getRecentDays().filter((dateKey) => this.getDailyPercent(dateKey) > 0).length).padStart(2, '0');
    this.renderFilterButtons();
    this.renderHeatmap();
    this.renderHabitList(visibleHabits);
    this.refreshIcons();
  }

  renderFilterButtons() {
    this.root.querySelectorAll('[data-habit-filter]').forEach((button) => {
      const isActive = button.dataset.habitFilter === this.filter;
      button.classList.toggle('habit-filter-button--active', isActive);
      button.setAttribute('aria-pressed', String(isActive));
    });
  }

  renderHeatmap() {
    const container = this.root.querySelector('[data-heatmap]');
    this.getRecentDays().forEach((dateKey) => {
      const percent = this.getDailyPercent(dateKey);
      const cell = document.createElement('button');
      cell.type = 'button';
      cell.className = `heatmap-cell heatmap-cell--${percent === 0 ? 0 : percent < 34 ? 1 : percent < 67 ? 2 : 3}`;
      cell.dataset.date = dateKey;
      cell.dataset.percent = percent;
      cell.setAttribute('aria-label', `${dayLabel(dateKey)}: выполнено ${percent}% привычек`);
      container.append(cell);
    });
  }

  renderHabitList(habits) {
    const list = this.root.querySelector('[data-habit-list]');
    const empty = this.root.querySelector('[data-habit-empty]');
    empty.hidden = habits.length > 0;
    habits.forEach((habit) => list.append(this.createHabitRow(habit)));
  }

  createHabitRow(habit) {
    const today = localDateKey();
    const completed = Boolean(habit.history?.[today]);
    const monthHits = this.getRecentDays(30).filter((dateKey) => habit.history?.[dateKey]).length;
    const row = document.createElement('article');
    row.className = `habit-row${completed ? ' habit-row--completed' : ''}`;
    row.dataset.habitId = habit.id;
    row.innerHTML = `
      <button class="habit-check" type="button" data-action="toggle-habit" role="checkbox" aria-checked="${completed}" aria-label="Отметить привычку"><i data-lucide="check" aria-hidden="true"></i></button>
      <div class="habit-row__content"><h4></h4><p></p><span></span></div>
      <div class="habit-row__metric"><b>${monthHits}/30</b><span>дней</span><div class="micro-bars"></div></div>
    `;
    row.querySelector('h4').textContent = habit.title;
    row.querySelector('p').textContent = habit.description;
    row.querySelector('.habit-row__content span').textContent = this.categoryLabel(habit.category);
    const bars = row.querySelector('.micro-bars');
    this.getRecentDays(7).forEach((dateKey) => {
      const segment = document.createElement('i');
      segment.classList.toggle('is-filled', Boolean(habit.history?.[dateKey]));
      bars.append(segment);
    });
    return row;
  }

  categoryLabel(category) {
    return ({ health: 'ЗДОРОВЬЕ', learning: 'ОБУЧЕНИЕ', focus: 'ФОКУС', mind: 'ОСОЗНАННОСТЬ' })[category] || 'ЛИЧНОЕ';
  }

  onRootClick(event) {
    const filter = event.target.closest('[data-habit-filter]');
    if (filter) {
      this.filter = FILTERS.has(filter.dataset.habitFilter) ? filter.dataset.habitFilter : 'all';
      this.render();
      return;
    }
    const habitToggle = event.target.closest('[data-action="toggle-habit"]');
    if (habitToggle) {
      const id = habitToggle.closest('[data-habit-id]')?.dataset.habitId;
      if (!id) return;
      const habit = this.storage.toggleHabit(id);
      this.notify(habit.history?.[localDateKey()] ? 'Привычка отмечена в сегодняшнем ритме.' : 'Отметка привычки снята.', 'success');
      return;
    }
    const heatCell = event.target.closest('[data-date][data-percent]');
    if (heatCell) {
      const tooltip = this.root.querySelector('[data-heatmap-tooltip]');
      tooltip.textContent = `${dayLabel(heatCell.dataset.date)} — выполнено ${heatCell.dataset.percent}% привычек.`;
    }
  }

  refreshIcons() {
    window.lucide?.createIcons({ attrs: { 'stroke-width': 1.75 } });
  }
}
