/**
 * Design reminder — Deep-Space Instrument Panel:
 * tags are compact data signals. Emerald is reserved for system action; category color comes from user data.
 */
const FALLBACK_COLOR = '#6B7280';

export class TagManager {
  constructor({ storage, root, notify = () => {} }) {
    if (!storage) throw new Error('TagManager requires StorageManager.');
    if (!root) throw new Error('TagManager requires a root element.');

    this.storage = storage;
    this.root = root;
    this.notify = notify;
    this.dialog = null;
    this.unsubscribe = null;
    this.onRootClick = this.onRootClick.bind(this);
    this.onDialogClick = this.onDialogClick.bind(this);
    this.onFormSubmit = this.onFormSubmit.bind(this);
  }

  mount() {
    this.createDialog();
    this.root.addEventListener('click', this.onRootClick);
    this.unsubscribe = this.storage.subscribe(() => this.render());
    this.render();
  }

  destroy() {
    this.root.removeEventListener('click', this.onRootClick);
    this.dialog?.removeEventListener('click', this.onDialogClick);
    this.dialog?.querySelector('form')?.removeEventListener('submit', this.onFormSubmit);
    this.dialog?.remove();
    this.unsubscribe?.();
  }

  getTagById(tagId) {
    return tagId ? this.storage.getTagById(tagId) : null;
  }

  getColorByTagId(tagId) {
    return this.getTagById(tagId)?.color || FALLBACK_COLOR;
  }

  render() {
    const tags = this.storage.getTags();
    this.root.replaceChildren();

    if (!tags.length) {
      const empty = document.createElement('p');
      empty.className = 'tag-empty-state';
      empty.textContent = 'Категорий пока нет. Создайте первую, чтобы структурировать задачи.';
      this.root.append(empty);
      return;
    }

    tags.forEach((tag) => this.root.append(this.createTagRow(tag)));
    this.refreshIcons();
  }

  createTagRow(tag) {
    const row = document.createElement('div');
    row.className = 'tag-row group';
    row.dataset.tagId = tag.id;
    row.innerHTML = `
      <span class="tag-row__signal" aria-hidden="true"></span>
      <span class="tag-row__name"></span>
      <span class="tag-row__hex"></span>
      <button class="tag-row__edit" type="button" data-action="edit-tag" aria-label="Изменить категорию"></button>
    `;
    row.querySelector('.tag-row__signal').style.backgroundColor = tag.color;
    row.querySelector('.tag-row__name').textContent = tag.name;
    row.querySelector('.tag-row__hex').textContent = tag.color;
    row.querySelector('.tag-row__edit').innerHTML = '<i data-lucide="pencil" aria-hidden="true"></i>';
    return row;
  }

  createDialog() {
    const dialog = document.createElement('dialog');
    dialog.className = 'tag-dialog';
    dialog.setAttribute('aria-labelledby', 'tag-dialog-title');
    dialog.innerHTML = `
      <div class="tag-dialog__surface">
        <header class="tag-dialog__header">
          <div>
            <p class="eyebrow">CATEGORY SIGNAL</p>
            <h2 id="tag-dialog-title">Новая категория</h2>
          </div>
          <button class="icon-button" type="button" data-action="close-dialog" aria-label="Закрыть окно">
            <i data-lucide="x" aria-hidden="true"></i>
          </button>
        </header>
        <form class="tag-form" novalidate>
          <input type="hidden" name="tagId" />
          <label class="field-label" for="tag-name">Название</label>
          <input class="field-input" id="tag-name" name="name" maxlength="40" autocomplete="off" required placeholder="Например, Финансы" />
          <div class="color-field">
            <div>
              <label class="field-label" for="tag-color">Сигнальный цвет</label>
              <p>Используется в задачах и календаре.</p>
            </div>
            <div class="color-field__controls">
              <input id="tag-color" name="color" type="color" value="#4EDEA3" aria-label="Выбрать цвет категории" />
              <output data-color-output>#4EDEA3</output>
            </div>
          </div>
          <p class="form-error" data-form-error role="alert" hidden></p>
          <footer class="tag-dialog__footer">
            <button class="secondary-button" type="button" data-action="close-dialog">Отмена</button>
            <button class="primary-button" type="submit"><i data-lucide="plus" aria-hidden="true"></i><span>Создать категорию</span></button>
          </footer>
          <button class="delete-tag-button" type="button" data-action="delete-tag" hidden><i data-lucide="trash-2" aria-hidden="true"></i>Удалить категорию</button>
        </form>
      </div>
    `;

    this.dialog = dialog;
    document.body.append(dialog);
    dialog.addEventListener('click', this.onDialogClick);
    dialog.querySelector('form').addEventListener('submit', this.onFormSubmit);
    dialog.querySelector('[name="color"]').addEventListener('input', (event) => {
      dialog.querySelector('[data-color-output]').textContent = event.target.value.toUpperCase();
    });
  }

  openCreateModal() {
    const form = this.dialog.querySelector('form');
    form.reset();
    form.elements.tagId.value = '';
    form.elements.color.value = '#4EDEA3';
    this.dialog.querySelector('[data-color-output]').textContent = '#4EDEA3';
    this.dialog.querySelector('#tag-dialog-title').textContent = 'Новая категория';
    this.dialog.querySelector('[type="submit"] span').textContent = 'Создать категорию';
    this.dialog.querySelector('[data-action="delete-tag"]').hidden = true;
    this.clearError();
    this.dialog.showModal();
    requestAnimationFrame(() => form.elements.name.focus());
    this.refreshIcons();
  }

  openEditModal(tagId) {
    const tag = this.getTagById(tagId);
    if (!tag) {
      this.notify('Категория больше не существует.', 'error');
      return;
    }

    const form = this.dialog.querySelector('form');
    form.elements.tagId.value = tag.id;
    form.elements.name.value = tag.name;
    form.elements.color.value = tag.color;
    this.dialog.querySelector('[data-color-output]').textContent = tag.color;
    this.dialog.querySelector('#tag-dialog-title').textContent = 'Изменить категорию';
    this.dialog.querySelector('[type="submit"] span').textContent = 'Сохранить изменения';
    this.dialog.querySelector('[data-action="delete-tag"]').hidden = false;
    this.clearError();
    this.dialog.showModal();
    requestAnimationFrame(() => form.elements.name.select());
    this.refreshIcons();
  }

  closeModal() {
    if (this.dialog?.open) this.dialog.close();
  }

  onRootClick(event) {
    const button = event.target.closest('[data-action]');
    if (!button) return;
    const { action } = button.dataset;
    if (action === 'create-tag') this.openCreateModal();
    if (action === 'edit-tag') this.openEditModal(button.closest('[data-tag-id]')?.dataset.tagId);
  }

  onDialogClick(event) {
    if (event.target === this.dialog) {
      this.closeModal();
      return;
    }
    const button = event.target.closest('[data-action]');
    if (!button) return;
    if (button.dataset.action === 'close-dialog') this.closeModal();
    if (button.dataset.action === 'delete-tag') this.deleteCurrentTag();
  }

  onFormSubmit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const data = Object.fromEntries(new FormData(form));
    try {
      if (data.tagId) {
        this.storage.updateTag(data.tagId, { name: data.name, color: data.color });
        this.notify('Категория обновлена.', 'success');
      } else {
        this.storage.saveTag({ name: data.name, color: data.color });
        this.notify('Категория создана.', 'success');
      }
      this.closeModal();
    } catch (error) {
      this.showError(error.message || 'Не удалось сохранить категорию.');
    }
  }

  deleteCurrentTag() {
    const tagId = this.dialog.querySelector('[name="tagId"]').value;
    const tag = this.getTagById(tagId);
    if (!tag) return this.closeModal();
    const accepted = window.confirm(`Удалить категорию «${tag.name}»? Связанные задачи останутся, но потеряют категорию.`);
    if (!accepted) return;
    this.storage.deleteTag(tagId);
    this.notify('Категория удалена. Связанные задачи получили статус «Без категории».', 'success');
    this.closeModal();
  }

  showError(message) {
    const target = this.dialog.querySelector('[data-form-error]');
    target.textContent = message;
    target.hidden = false;
  }

  clearError() {
    const target = this.dialog.querySelector('[data-form-error]');
    target.textContent = '';
    target.hidden = true;
  }

  refreshIcons() {
    window.lucide?.createIcons({ attrs: { 'stroke-width': 1.75 } });
  }
}
