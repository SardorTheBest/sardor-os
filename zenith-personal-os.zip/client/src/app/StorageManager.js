/**
 * Design reminder — Deep-Space Instrument Panel:
 * this module owns data persistence only. UI modules never write localStorage directly.
 */
import {
  DEFAULT_TAGS,
  DEFAULT_USER,
  DEFAULT_HABITS,
  DEFAULT_BOOKS,
  EMPTY_STORE,
  SCHEMA_VERSION,
  STORAGE_KEY,
} from './constants.js';
import { createId } from '../utils/id.js';

const HEX_COLOR = /^#[0-9A-F]{6}$/i;
const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const ISO_TIME = /^\d{2}:\d{2}$/;

const clone = (value) => structuredClone(value);
const now = () => new Date().toISOString();

/**
 * Local-first storage gateway.
 *
 * Task shape:
 * { id, title, description, isCompleted, dueDate, dueTime, tagId,
 *   createdAt, updatedAt, isSynced }
 *
 * Tag shape:
 * { id, name, color, updatedAt, isSynced }
 *
 * Habit shape:
 * { id, title, category, description, streak, history, createdAt, updatedAt, isSynced }
 *
 * Book shape:
 * { id, title, author, genre, totalPages, readPages, status, coverTone, quotes, notes,
 *   createdAt, updatedAt, isSynced }
 */
export class StorageManager {
  constructor(storageKey = STORAGE_KEY) {
    this.storageKey = storageKey;
    this.listeners = new Set();
    this.initialize();
  }

  initialize() {
    const existing = this.readRawStore();
    if (!existing) {
      const timestamp = now();
      const firstStore = {
        ...clone(EMPTY_STORE),
        deviceId: createId('device'),
        tags: DEFAULT_TAGS.map((tag) => ({
          ...tag,
          updatedAt: timestamp,
          isSynced: false,
        })),
        user: clone(DEFAULT_USER),
        habits: DEFAULT_HABITS.map((habit) => this.normalizeHabit({
          ...habit,
          createdAt: timestamp,
          updatedAt: timestamp,
          isSynced: false,
        }, timestamp)),
        books: DEFAULT_BOOKS.map((book) => this.normalizeBook({
          ...book,
          createdAt: timestamp,
          updatedAt: timestamp,
          isSynced: false,
        }, timestamp)),
        meta: { createdAt: timestamp, updatedAt: timestamp },
      };
      this.writeStore(firstStore, { notify: false });
      return;
    }

    const normalized = this.normalizeStore(existing);
    this.writeStore(normalized, { notify: false });
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  getSnapshot() {
    return clone(this.readStore());
  }

  getTasks() {
    return clone(this.readStore().tasks);
  }

  getTaskById(id) {
    const task = this.readStore().tasks.find((item) => item.id === id);
    return task ? clone(task) : null;
  }

  saveTask(task) {
    const store = this.readStore();
    const timestamp = now();
    const record = this.normalizeTask({
      ...task,
      id: task?.id || createId('task'),
      createdAt: task?.createdAt || timestamp,
      updatedAt: timestamp,
      isSynced: false,
    });

    if (store.tasks.some((item) => item.id === record.id)) {
      throw new Error(`Задача с id «${record.id}» уже существует.`);
    }

    store.tasks.push(record);
    this.writeStore(store, { type: 'task:saved', item: record });
    return clone(record);
  }

  updateTask(id, data) {
    const store = this.readStore();
    const index = store.tasks.findIndex((item) => item.id === id);
    if (index === -1) throw new Error('Задача не найдена.');

    const record = this.normalizeTask({
      ...store.tasks[index],
      ...data,
      id,
      createdAt: store.tasks[index].createdAt,
      updatedAt: now(),
      isSynced: false,
    });
    store.tasks[index] = record;
    this.writeStore(store, { type: 'task:updated', item: record });
    return clone(record);
  }

  deleteTask(id) {
    const store = this.readStore();
    const index = store.tasks.findIndex((item) => item.id === id);
    if (index === -1) return false;

    const [deleted] = store.tasks.splice(index, 1);
    this.addTombstone(store, 'tasks', deleted.id);
    this.writeStore(store, { type: 'task:deleted', item: { id: deleted.id } });
    return true;
  }

  getUser() {
    return clone(this.readStore().user);
  }

  updateUser(data) {
    const store = this.readStore();
    const dailyGoal = Number(data?.dailyGoal ?? store.user.dailyGoal);
    if (!Number.isInteger(dailyGoal) || dailyGoal < 1 || dailyGoal > 99) {
      throw new Error('Ежедневная цель должна быть целым числом от 1 до 99.');
    }
    store.user = {
      ...store.user,
      ...data,
      name: String(data?.name ?? store.user.name).trim() || 'Пользователь',
      dailyGoal,
    };
    this.writeStore(store, { type: 'user:updated', item: store.user });
    return clone(store.user);
  }

  getHabits() {
    return clone(this.readStore().habits);
  }

  getHabitById(id) {
    const habit = this.readStore().habits.find((item) => item.id === id);
    return habit ? clone(habit) : null;
  }

  saveHabit(habit) {
    const store = this.readStore();
    const timestamp = now();
    const record = this.normalizeHabit({
      ...habit,
      id: habit?.id || createId('habit'),
      createdAt: habit?.createdAt || timestamp,
      updatedAt: timestamp,
      isSynced: false,
    });
    if (store.habits.some((item) => item.id === record.id)) {
      throw new Error(`Привычка с id «${record.id}» уже существует.`);
    }
    store.habits.push(record);
    this.writeStore(store, { type: 'habit:saved', item: record });
    return clone(record);
  }

  updateHabit(id, data) {
    const store = this.readStore();
    const index = store.habits.findIndex((item) => item.id === id);
    if (index === -1) throw new Error('Привычка не найдена.');
    const record = this.normalizeHabit({
      ...store.habits[index],
      ...data,
      id,
      createdAt: store.habits[index].createdAt,
      updatedAt: now(),
      isSynced: false,
    });
    store.habits[index] = record;
    this.writeStore(store, { type: 'habit:updated', item: record });
    return clone(record);
  }

  deleteHabit(id) {
    const store = this.readStore();
    const index = store.habits.findIndex((item) => item.id === id);
    if (index === -1) return false;
    const [deleted] = store.habits.splice(index, 1);
    this.addTombstone(store, 'habits', deleted.id);
    this.writeStore(store, { type: 'habit:deleted', item: { id: deleted.id } });
    return true;
  }

  toggleHabit(id, dateKey = this.getLocalDateKey()) {
    const store = this.readStore();
    const index = store.habits.findIndex((item) => item.id === id);
    if (index === -1) throw new Error('Привычка не найдена.');
    const habit = store.habits[index];
    const nextHistory = { ...habit.history };
    nextHistory[dateKey] = !nextHistory[dateKey];
    if (!nextHistory[dateKey]) delete nextHistory[dateKey];
    const record = this.normalizeHabit({
      ...habit,
      history: nextHistory,
      streak: this.calculateStreak(nextHistory, dateKey),
      updatedAt: now(),
      isSynced: false,
    });
    store.habits[index] = record;
    this.writeStore(store, { type: 'habit:toggled', item: record, dateKey });
    return clone(record);
  }

  getHabitStats(dateKey = this.getLocalDateKey()) {
    const habits = this.getHabits();
    const completed = habits.filter((habit) => Boolean(habit.history?.[dateKey])).length;
    const longestStreak = habits.reduce((max, habit) => Math.max(max, habit.streak || 0), 0);
    return {
      total: habits.length,
      completed,
      percent: habits.length ? Math.round((completed / habits.length) * 100) : 0,
      longestStreak,
    };
  }

  getBooks() {
    return clone(this.readStore().books);
  }

  getBookById(id) {
    const book = this.readStore().books.find((item) => item.id === id);
    return book ? clone(book) : null;
  }

  saveBook(book) {
    const store = this.readStore();
    const timestamp = now();
    const record = this.normalizeBook({
      ...book,
      id: book?.id || createId('book'),
      createdAt: book?.createdAt || timestamp,
      updatedAt: timestamp,
      isSynced: false,
    });
    if (store.books.some((item) => item.id === record.id)) {
      throw new Error(`Книга с id «${record.id}» уже существует.`);
    }
    store.books.push(record);
    this.writeStore(store, { type: 'book:saved', item: record });
    return clone(record);
  }

  updateBook(id, data) {
    const store = this.readStore();
    const index = store.books.findIndex((item) => item.id === id);
    if (index === -1) throw new Error('Книга не найдена.');
    const record = this.normalizeBook({
      ...store.books[index],
      ...data,
      id,
      createdAt: store.books[index].createdAt,
      updatedAt: now(),
      isSynced: false,
    });
    store.books[index] = record;
    this.writeStore(store, { type: 'book:updated', item: record });
    return clone(record);
  }

  deleteBook(id) {
    const store = this.readStore();
    const index = store.books.findIndex((item) => item.id === id);
    if (index === -1) return false;
    const [deleted] = store.books.splice(index, 1);
    this.addTombstone(store, 'books', deleted.id);
    this.writeStore(store, { type: 'book:deleted', item: { id: deleted.id } });
    return true;
  }

  addReadPages(id, pages) {
    const book = this.getBookById(id);
    const amount = Number(pages);
    if (!book) throw new Error('Книга не найдена.');
    if (!Number.isInteger(amount) || amount < 1) throw new Error('Количество страниц должно быть положительным целым числом.');
    return this.updateBook(id, { readPages: Math.min(book.totalPages, book.readPages + amount) });
  }

  addBookQuote(id, content) {
    const book = this.getBookById(id);
    const text = String(content || '').trim();
    if (!book) throw new Error('Книга не найдена.');
    if (!text) throw new Error('Введите текст цитаты.');
    const quotes = [...book.quotes, { id: createId('quote'), content: text, createdAt: now() }];
    return this.updateBook(id, { quotes });
  }

  getBookStats() {
    const books = this.getBooks();
    return {
      total: books.length,
      completed: books.filter((book) => book.status === 'completed').length,
      reading: books.filter((book) => book.status === 'reading').length,
      totalReadPages: books.reduce((sum, book) => sum + book.readPages, 0),
    };
  }

  getTags() {
    return clone(this.readStore().tags);
  }

  getTagById(id) {
    const tag = this.readStore().tags.find((item) => item.id === id);
    return tag ? clone(tag) : null;
  }

  saveTag(tag) {
    const store = this.readStore();
    const timestamp = now();
    const record = this.normalizeTag({
      ...tag,
      id: tag?.id || createId('tag'),
      updatedAt: timestamp,
      isSynced: false,
    });
    this.assertUniqueTagName(store.tags, record.name);

    if (store.tags.some((item) => item.id === record.id)) {
      throw new Error(`Тег с id «${record.id}» уже существует.`);
    }

    store.tags.push(record);
    this.writeStore(store, { type: 'tag:saved', item: record });
    return clone(record);
  }

  updateTag(id, data) {
    const store = this.readStore();
    const index = store.tags.findIndex((item) => item.id === id);
    if (index === -1) throw new Error('Категория не найдена.');

    const record = this.normalizeTag({
      ...store.tags[index],
      ...data,
      id,
      updatedAt: now(),
      isSynced: false,
    });
    this.assertUniqueTagName(store.tags, record.name, id);
    store.tags[index] = record;
    this.writeStore(store, { type: 'tag:updated', item: record });
    return clone(record);
  }

  deleteTag(id) {
    const store = this.readStore();
    const index = store.tags.findIndex((item) => item.id === id);
    if (index === -1) return false;

    const [deleted] = store.tags.splice(index, 1);
    const timestamp = now();
    const affectedTaskIds = [];

    store.tasks = store.tasks.map((task) => {
      if (task.tagId !== id) return task;
      affectedTaskIds.push(task.id);
      return { ...task, tagId: null, updatedAt: timestamp, isSynced: false };
    });

    this.addTombstone(store, 'tags', deleted.id);
    this.writeStore(store, {
      type: 'tag:deleted',
      item: { id: deleted.id, affectedTaskIds },
    });
    return true;
  }

  readRawStore() {
    try {
      const raw = localStorage.getItem(this.storageKey);
      return raw ? JSON.parse(raw) : null;
    } catch (error) {
      console.warn('Zenith storage is unreadable; a new local store will be created.', error);
      return null;
    }
  }

  readStore() {
    return this.normalizeStore(this.readRawStore() || clone(EMPTY_STORE));
  }

  writeStore(store, event = {}) {
    const timestamp = now();
    const nextStore = this.normalizeStore({
      ...store,
      meta: { ...store.meta, updatedAt: timestamp },
    });
    localStorage.setItem(this.storageKey, JSON.stringify(nextStore));
    if (event.notify !== false) {
      const detail = { ...event, store: clone(nextStore) };
      this.listeners.forEach((listener) => listener(detail));
      window.dispatchEvent(new CustomEvent('zenith:storage-changed', { detail }));
    }
    return clone(nextStore);
  }

  normalizeStore(input) {
    const timestamp = now();
    const safe = input && typeof input === 'object' ? input : {};
    const tasks = Array.isArray(safe.tasks) ? safe.tasks : [];
    const hasStoredTags = Array.isArray(safe.tags);
    const tags = hasStoredTags ? safe.tags : [];
    const hasStoredHabits = Array.isArray(safe.habits);
    const hasStoredBooks = Array.isArray(safe.books);

    return {
      ...clone(EMPTY_STORE),
      ...safe,
      schemaVersion: SCHEMA_VERSION,
      deviceId: safe.deviceId || createId('device'),
      user: {
        ...clone(DEFAULT_USER),
        ...(safe.user || {}),
        name: String(safe.user?.name || DEFAULT_USER.name).trim() || DEFAULT_USER.name,
        dailyGoal: Number.isInteger(Number(safe.user?.dailyGoal)) && Number(safe.user?.dailyGoal) > 0
          ? Number(safe.user.dailyGoal)
          : DEFAULT_USER.dailyGoal,
      },
      tasks: tasks.map((task) => this.normalizeTask(task, timestamp)),
      tags: hasStoredTags
        ? tags.map((tag) => this.normalizeTag(tag, timestamp))
        : DEFAULT_TAGS.map((tag) => this.normalizeTag({
          ...tag,
          updatedAt: timestamp,
          isSynced: false,
        }, timestamp)),
      habits: hasStoredHabits
        ? safe.habits.map((habit) => this.normalizeHabit(habit, timestamp))
        : DEFAULT_HABITS.map((habit) => this.normalizeHabit({
          ...habit, createdAt: timestamp, updatedAt: timestamp, isSynced: false,
        }, timestamp)),
      books: hasStoredBooks
        ? safe.books.map((book) => this.normalizeBook(book, timestamp))
        : DEFAULT_BOOKS.map((book) => this.normalizeBook({
          ...book, createdAt: timestamp, updatedAt: timestamp, isSynced: false,
        }, timestamp)),
      sync: {
        ...clone(EMPTY_STORE.sync),
        ...(safe.sync || {}),
        tombstones: Array.isArray(safe.sync?.tombstones) ? safe.sync.tombstones : [],
      },
      meta: {
        createdAt: safe.meta?.createdAt || timestamp,
        updatedAt: safe.meta?.updatedAt || timestamp,
      },
    };
  }

  normalizeTask(task, fallbackTimestamp = now()) {
    const record = task && typeof task === 'object' ? task : {};
    const title = String(record.title || '').trim();
    if (!title) throw new Error('Укажите название задачи.');
    if (record.dueDate && !ISO_DATE.test(record.dueDate)) {
      throw new Error('Дата задачи должна иметь формат YYYY-MM-DD.');
    }
    if (record.dueTime && !ISO_TIME.test(record.dueTime)) {
      throw new Error('Время задачи должно иметь формат HH:MM.');
    }

    return {
      id: String(record.id || createId('task')),
      title,
      description: String(record.description || '').trim(),
      isCompleted: Boolean(record.isCompleted),
      dueDate: record.dueDate || null,
      dueTime: record.dueTime || null,
      tagId: record.tagId || null,
      createdAt: record.createdAt || fallbackTimestamp,
      updatedAt: record.updatedAt || fallbackTimestamp,
      isSynced: Boolean(record.isSynced),
    };
  }

  normalizeTag(tag, fallbackTimestamp = now()) {
    const record = tag && typeof tag === 'object' ? tag : {};
    const name = String(record.name || '').trim();
    const color = String(record.color || '').toUpperCase();
    if (!name) throw new Error('Укажите название категории.');
    if (!HEX_COLOR.test(color)) throw new Error('Цвет категории должен иметь формат #RRGGBB.');

    return {
      id: String(record.id || createId('tag')),
      name,
      color,
      updatedAt: record.updatedAt || fallbackTimestamp,
      isSynced: Boolean(record.isSynced),
    };
  }

  normalizeHabit(habit, fallbackTimestamp = now()) {
    const record = habit && typeof habit === 'object' ? habit : {};
    const title = String(record.title || '').trim();
    const allowedCategories = new Set(['health', 'learning', 'focus', 'mind']);
    if (!title) throw new Error('Укажите название привычки.');
    const category = allowedCategories.has(record.category) ? record.category : 'mind';
    const history = record.history && typeof record.history === 'object' && !Array.isArray(record.history)
      ? Object.fromEntries(Object.entries(record.history).filter(([date, value]) => ISO_DATE.test(date) && Boolean(value)))
      : {};
    return {
      id: String(record.id || createId('habit')),
      title,
      category,
      description: String(record.description || '').trim(),
      streak: Number.isInteger(Number(record.streak)) && Number(record.streak) >= 0
        ? Number(record.streak)
        : this.calculateStreak(history),
      history,
      createdAt: record.createdAt || fallbackTimestamp,
      updatedAt: record.updatedAt || fallbackTimestamp,
      isSynced: Boolean(record.isSynced),
    };
  }

  normalizeBook(book, fallbackTimestamp = now()) {
    const record = book && typeof book === 'object' ? book : {};
    const title = String(record.title || '').trim();
    const totalPages = Number(record.totalPages);
    const readPages = Number(record.readPages || 0);
    if (!title) throw new Error('Укажите название книги.');
    if (!Number.isInteger(totalPages) || totalPages < 1) throw new Error('Общее количество страниц должно быть положительным целым числом.');
    if (!Number.isInteger(readPages) || readPages < 0) throw new Error('Количество прочитанных страниц не может быть отрицательным.');
    const boundedPages = Math.min(readPages, totalPages);
    const quotes = Array.isArray(record.quotes) ? record.quotes.map((quote) => {
      if (typeof quote === 'string') return { id: createId('quote'), content: quote.trim(), createdAt: fallbackTimestamp };
      return {
        id: String(quote?.id || createId('quote')),
        content: String(quote?.content || '').trim(),
        createdAt: quote?.createdAt || fallbackTimestamp,
      };
    }).filter((quote) => quote.content) : [];
    const completed = boundedPages === totalPages;
    return {
      id: String(record.id || createId('book')),
      title,
      author: String(record.author || 'Не указан').trim() || 'Не указан',
      genre: String(record.genre || 'Без жанра').trim() || 'Без жанра',
      totalPages,
      readPages: boundedPages,
      status: completed ? 'completed' : (['reading', 'planned'].includes(record.status) ? record.status : 'reading'),
      coverTone: ['emerald', 'violet', 'sky', 'orange'].includes(record.coverTone) ? record.coverTone : 'emerald',
      quotes,
      notes: String(record.notes || '').trim(),
      createdAt: record.createdAt || fallbackTimestamp,
      updatedAt: record.updatedAt || fallbackTimestamp,
      isSynced: Boolean(record.isSynced),
    };
  }

  calculateStreak(history, fromDate = this.getLocalDateKey()) {
    let cursor = this.parseLocalDate(fromDate);
    let streak = 0;
    while (cursor && history[this.getLocalDateKey(cursor)]) {
      streak += 1;
      cursor.setDate(cursor.getDate() - 1);
    }
    return streak;
  }

  getLocalDateKey(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  parseLocalDate(dateKey) {
    if (!ISO_DATE.test(String(dateKey))) return null;
    const [year, month, day] = dateKey.split('-').map(Number);
    return new Date(year, month - 1, day);
  }

  assertUniqueTagName(tags, name, currentId = null) {
    const duplicate = tags.some((tag) => (
      tag.id !== currentId && tag.name.localeCompare(name, 'ru', { sensitivity: 'accent' }) === 0
    ));
    if (duplicate) throw new Error('Категория с таким названием уже существует.');
  }

  addTombstone(store, collection, id) {
    const timestamp = now();
    store.sync = store.sync || { tombstones: [] };
    store.sync.tombstones = [
      ...(store.sync.tombstones || []).filter((item) => !(item.collection === collection && item.id === id)),
      { id, collection, deletedAt: timestamp, updatedAt: timestamp, isSynced: false },
    ];
  }
}
