/** Smoke test for Sprint 4 reactive AppState facade. Run with node client/src/app/AppState.smoke.mjs. */
const memory = new Map();
globalThis.localStorage = {
  getItem(key) { return memory.has(key) ? memory.get(key) : null; },
  setItem(key, value) { memory.set(key, String(value)); },
  removeItem(key) { memory.delete(key); },
};
globalThis.window = { addEventListener() {}, removeEventListener() {}, dispatchEvent() {} };
globalThis.CustomEvent = class CustomEvent { constructor(type, init = {}) { this.type = type; this.detail = init.detail; } };

const { StorageManager } = await import('./StorageManager.js');
const { AppState } = await import('./AppState.js');
const assert = (condition, message) => { if (!condition) throw new Error(message); };

const storage = new StorageManager('zenith-app-state-smoke');
const appState = new AppState(storage);
let changeCount = 0;
appState.subscribe(() => { changeCount += 1; });

const initial = appState.getSnapshot();
assert(initial.user.name === 'Sardor', 'AppState должен гидрировать профиль из начального local snapshot.');
assert(initial.habits.length === 3 && initial.books.length === 1, 'AppState должен включать все доменные коллекции.');
assert(initial.stats.todayCompletedHabits === 0, 'Начальная метрика привычек должна быть вычислена.');

appState.toggleHabit(initial.habits[0].id, '2026-08-27');
const afterHabit = appState.getSnapshot();
assert(afterHabit.stats.todayCompletedHabits === 1, 'Чек-ин привычки должен немедленно обновить derived stats.');
assert(afterHabit.habits[0].isSynced === false, 'Изменение привычки должно оставаться local-first unsynced.');

const initialPages = afterHabit.books[0].readPages;
appState.addReadPages(afterHabit.books[0].id, 4);
const afterBook = appState.getSnapshot();
assert(afterBook.books[0].readPages === initialPages + 4, 'Прогресс чтения должен попасть в единый snapshot.');
assert(afterBook.stats.totalReadPages === initialPages + 4, 'Метрика страниц должна пересчитываться реактивно.');
assert(changeCount >= 2, 'Подписчики AppState должны получать изменения доменных данных.');
assert(JSON.parse(localStorage.getItem('zenith-app-state-smoke')).books[0].readPages === initialPages + 4, 'AppState должен сохраняться StorageManager автоматически.');

appState.destroy();
console.log('AppState smoke test passed.');
