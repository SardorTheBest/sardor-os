/**
 * Design reminder — Deep-Space Instrument Panel:
 * persist local data under one versioned key; all write operations remain local-first.
 */
export const STORAGE_KEY = 'zenith-personal-os:v3';
export const SCHEMA_VERSION = 4;

export const DEFAULT_TAGS = Object.freeze([
  { id: 'tag_study', name: 'Учёба', color: '#8B5CF6' },
  { id: 'tag_projects', name: 'Проекты', color: '#3B82F6' },
  { id: 'tag_personal', name: 'Личное', color: '#10B981' },
  { id: 'tag_sport', name: 'Спорт', color: '#F97316' },
]);

export const DEFAULT_USER = Object.freeze({
  name: 'Sardor',
  dailyGoal: 5,
});

export const DEFAULT_HABITS = Object.freeze([
  { id: 'habit_reading', title: 'Чтение (30 мин)', category: 'learning', description: 'Минимум 30 минут с текущей книгой.' },
  { id: 'habit_training', title: 'Утренняя тренировка', category: 'health', description: 'Движение, сила или кардио в своём темпе.' },
  { id: 'habit_deep_work', title: 'Блок глубокой работы', category: 'focus', description: 'Один защищённый блок без отвлечений.' },
]);

export const DEFAULT_BOOKS = Object.freeze([
  {
    id: 'book_clean_code',
    title: 'Чистый код',
    author: 'Роберт Мартин',
    genre: 'Разработка',
    totalPages: 464,
    readPages: 180,
    status: 'reading',
    coverTone: 'emerald',
    quotes: [],
    notes: '',
  },
]);

export const EMPTY_STORE = Object.freeze({
  schemaVersion: SCHEMA_VERSION,
  deviceId: null,
  user: DEFAULT_USER,
  tasks: [],
  tags: [],
  habits: [],
  books: [],
  sync: {
    status: 'local',
    lastSyncAt: null,
    lastError: null,
    tombstones: [],
  },
  meta: {
    createdAt: null,
    updatedAt: null,
  },
});
