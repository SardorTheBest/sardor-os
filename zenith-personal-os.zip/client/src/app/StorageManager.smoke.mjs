/**
 * Smoke test — validates local-first Sprint 1 persistence without a browser runtime.
 * Run with: node client/src/app/StorageManager.smoke.mjs
 */
const storage = new Map();

globalThis.localStorage = {
  getItem(key) { return storage.has(key) ? storage.get(key) : null; },
  setItem(key, value) { storage.set(key, String(value)); },
  removeItem(key) { storage.delete(key); },
};
globalThis.window = {
  dispatchEvent() {},
};
globalThis.CustomEvent = class CustomEvent {
  constructor(type, init) {
    this.type = type;
    this.detail = init?.detail;
  }
};

const { StorageManager } = await import('./StorageManager.js');

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const manager = new StorageManager('zenith-sprint-1-smoke');
assert(manager.getTags().length === 4, 'Первый запуск должен создать четыре дефолтных тега.');
assert(manager.getHabits().length === 3, 'Миграция Sprint 3 должна создать три дефолтные привычки.');
assert(manager.getBooks().length === 1, 'Миграция Sprint 3 должна создать текущую книгу.');

const habit = manager.getHabits()[0];
const checkedHabit = manager.toggleHabit(habit.id, '2026-08-27');
assert(checkedHabit.history['2026-08-27'] === true && checkedHabit.streak === 1, 'Отметка привычки должна обновить history и streak.');
const uncheckedHabit = manager.toggleHabit(habit.id, '2026-08-27');
assert(!uncheckedHabit.history['2026-08-27'] && uncheckedHabit.isSynced === false, 'Снятие отметки привычки должно сохраниться локально.');

const book = manager.getBooks()[0];
const progressedBook = manager.addReadPages(book.id, 10);
assert(progressedBook.readPages === 190 && progressedBook.isSynced === false, 'Прогресс чтения должен сохраняться с unsynced-флагом.');
const citedBook = manager.addBookQuote(book.id, 'Прозрачный код легче сопровождать.');
assert(citedBook.quotes.length === 1 && citedBook.quotes[0].content.includes('Прозрачный код'), 'Цитата должна добавляться к книге.');

const task = manager.saveTask({
  title: 'Подготовить архитектуру',
  description: 'Проверить локальное хранилище.',
  isCompleted: false,
  dueDate: '2026-08-27',
  dueTime: '10:00',
  tagId: 'tag_study',
});
assert(task.isSynced === false && Boolean(task.updatedAt), 'Новая задача должна быть unsynced и иметь updatedAt.');

const complete = manager.updateTask(task.id, { isCompleted: true });
assert(complete.isCompleted === true && complete.isSynced === false, 'Изменение задачи должно сохраняться локально и быть unsynced.');

const tag = manager.saveTag({ name: 'Финансы', color: '#14B8A6' });
assert(manager.getTagById(tag.id)?.color === '#14B8A6', 'Новый тег должен быть доступен по id.');

const revisedTag = manager.updateTag(tag.id, { name: 'Домашние финансы', color: '#0EA5E9' });
assert(revisedTag.isSynced === false && revisedTag.color === '#0EA5E9', 'Изменённый тег должен получить обновлённый цвет и unsynced-флаг.');

manager.updateTask(task.id, { tagId: revisedTag.id });
assert(manager.deleteTag(revisedTag.id) === true, 'Тег должен удаляться.');
assert(manager.getTaskById(task.id)?.tagId === null, 'Удаление тега должно очищать tagId связанной задачи.');
assert(manager.getSnapshot().sync.tombstones.some((item) => item.id === revisedTag.id), 'Удаление тега должно сохранять tombstone для будущей синхронизации.');

for (const defaultTag of manager.getTags()) manager.deleteTag(defaultTag.id);
assert(manager.getTags().length === 0, 'Удаление последней категории не должно восстанавливать дефолтные теги.');

assert(manager.deleteTask(task.id) === true, 'Задача должна удаляться.');
assert(manager.getTasks().length === 0, 'После удаления список задач должен быть пустым.');

console.log('StorageManager smoke test passed.');
