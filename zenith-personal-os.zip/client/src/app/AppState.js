/**
 * Design reminder — Deep-Space Instrument Panel:
 * state is deliberately infrastructure-only; it never contains UI styling or view-specific markup.
 * All screens observe this single local-first facade rather than accessing localStorage independently.
 */
const clone = (value) => structuredClone(value);

/**
 * Reactive in-memory facade for the versioned StorageManager snapshot.
 * StorageManager remains the only persistence gateway; AppState guarantees that dashboard,
 * habits, books, tasks, and tags always observe the same hydrated local state.
 */
export class AppState {
  constructor(storage) {
    if (!storage) throw new Error('AppState requires StorageManager.');
    this.storage = storage;
    this.storageKey = storage.storageKey;
    this.listeners = new Set();
    this.state = this.hydrate();
    this.unsubscribeStorage = storage.subscribe((event) => this.commit(event));
    this.onNativeStorage = this.onNativeStorage.bind(this);
    window.addEventListener('storage', this.onNativeStorage);
  }

  hydrate() {
    const snapshot = this.storage.getSnapshot();
    this.state = this.withDerivedStats(snapshot);
    return clone(this.state);
  }

  getSnapshot() {
    return clone(this.state);
  }

  get user() { return clone(this.state.user); }
  get tasks() { return clone(this.state.tasks); }
  get tags() { return clone(this.state.tags); }
  get habits() { return clone(this.state.habits); }
  get books() { return clone(this.state.books); }
  get stats() { return clone(this.state.stats); }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  destroy() {
    this.unsubscribeStorage?.();
    window.removeEventListener('storage', this.onNativeStorage);
    this.listeners.clear();
  }

  commit(event = { type: 'state:hydrated' }) {
    this.state = this.withDerivedStats(event.store ? clone(event.store) : this.storage.getSnapshot());
    const detail = { ...event, store: this.getSnapshot() };
    this.listeners.forEach((listener) => listener(detail));
    window.dispatchEvent(new CustomEvent('zenith:state-changed', { detail }));
  }

  onNativeStorage(event) {
    if (event.key === this.storageKey) this.commit({ type: 'state:hydrated' });
  }

  withDerivedStats(snapshot) {
    const today = this.getLocalDateKey();
    const habits = Array.isArray(snapshot.habits) ? snapshot.habits : [];
    const books = Array.isArray(snapshot.books) ? snapshot.books : [];
    const tasks = Array.isArray(snapshot.tasks) ? snapshot.tasks : [];
    const todayCompletedHabits = habits.filter((habit) => Boolean(habit.history?.[today])).length;
    return {
      ...snapshot,
      stats: {
        todayCompletedHabits,
        totalHabits: habits.length,
        habitCompletionPercent: habits.length ? Math.round((todayCompletedHabits / habits.length) * 100) : 0,
        totalBooksCompleted: books.filter((book) => book.status === 'completed').length,
        totalReadPages: books.reduce((sum, book) => sum + book.readPages, 0),
        openTasks: tasks.filter((task) => !task.isCompleted).length,
        completedTasks: tasks.filter((task) => task.isCompleted).length,
      },
    };
  }

  getLocalDateKey(date = new Date()) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  getUser() { return this.storage.getUser(); }
  updateUser(data) { return this.storage.updateUser(data); }
  getTasks() { return this.storage.getTasks(); }
  getTaskById(id) { return this.storage.getTaskById(id); }
  saveTask(task) { return this.storage.saveTask(task); }
  updateTask(id, data) { return this.storage.updateTask(id, data); }
  deleteTask(id) { return this.storage.deleteTask(id); }
  getTags() { return this.storage.getTags(); }
  getTagById(id) { return this.storage.getTagById(id); }
  saveTag(tag) { return this.storage.saveTag(tag); }
  updateTag(id, data) { return this.storage.updateTag(id, data); }
  deleteTag(id) { return this.storage.deleteTag(id); }
  getHabits() { return this.storage.getHabits(); }
  getHabitById(id) { return this.storage.getHabitById(id); }
  saveHabit(habit) { return this.storage.saveHabit(habit); }
  updateHabit(id, data) { return this.storage.updateHabit(id, data); }
  deleteHabit(id) { return this.storage.deleteHabit(id); }
  toggleHabit(id, dateKey) { return this.storage.toggleHabit(id, dateKey); }
  getHabitStats(dateKey) { return this.storage.getHabitStats(dateKey); }
  getBooks() { return this.storage.getBooks(); }
  getBookById(id) { return this.storage.getBookById(id); }
  saveBook(book) { return this.storage.saveBook(book); }
  updateBook(id, data) { return this.storage.updateBook(id, data); }
  deleteBook(id) { return this.storage.deleteBook(id); }
  addReadPages(id, pages) { return this.storage.addReadPages(id, pages); }
  addBookQuote(id, content) { return this.storage.addBookQuote(id, content); }
  getBookStats() { return this.storage.getBookStats(); }
}
