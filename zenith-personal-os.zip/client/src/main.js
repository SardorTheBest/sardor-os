/**
 * Design reminder — Deep-Space Instrument Panel:
 * all routes remain live translations of the supplied Deep Space OS screens—dark tonal surfaces, emerald action, violet focus and monospaced metadata.
 */
import './styles.css';
import './calendar.css';
import { StorageManager } from './app/StorageManager.js';
import { AppState } from './app/AppState.js';
import { TagManager } from './modules/tags/TagManager.js';
import { TodoModule } from './modules/todo/TodoModule.js';
import { CalendarModule } from './modules/calendar/CalendarModule.js';
import { HabitModule } from './modules/habits/HabitModule.js';
import { BookModule } from './modules/books/BookModule.js';
import { DashboardModule } from './modules/dashboard/DashboardModule.js';

const icon = (name, className = '') => `<i data-lucide="${name}" class="${className}" aria-hidden="true"></i>`;
const app = document.querySelector('#app');

app.innerHTML = `
  <div class="app-frame min-h-screen text-slate-100">
    <aside class="sidebar" aria-label="Основная навигация">
      <div class="brand-lockup">
        <div class="brand-mark" role="img" aria-label="Знак Zenith: четыре орбитальных сегмента формируют абстрактную букву Z">
          <img src="/manus-storage/zenith-orbital-mark_8c51b6da.png" alt="" aria-hidden="true" width="48" height="48" />
          <span class="brand-mark__orbit brand-mark__orbit--one" aria-hidden="true"></span><span class="brand-mark__orbit brand-mark__orbit--two" aria-hidden="true"></span><span class="brand-mark__orbit brand-mark__orbit--three" aria-hidden="true"></span><span class="brand-mark__orbit brand-mark__orbit--four" aria-hidden="true"></span><span class="brand-mark__core" aria-hidden="true"></span>
        </div>
        <div><p class="brand-wordmark">ZENITH</p><p class="brand-version">PERSONAL OS / 01</p></div>
      </div>
      <nav class="nav-stack" aria-label="Разделы приложения">
        <button class="nav-item nav-item--active" type="button" data-view="dashboard" aria-current="page">${icon('layout-dashboard')}<span>Сегодня</span></button>
        <button class="nav-item" type="button" data-view="tasks">${icon('check-circle-2')}<span>Задачи</span></button>
        <button class="nav-item" type="button" data-view="calendar">${icon('calendar-days')}<span>Календарь</span></button>
        <button class="nav-item" type="button" data-view="books">${icon('book-open')}<span>Книги</span></button>
        <button class="nav-item" type="button" data-view="habits">${icon('orbit')}<span>Привычки</span></button>
        <button class="nav-item" type="button" data-open-tags>${icon('tags')}<span>Категории</span></button>
      </nav>
      <div class="sidebar-footer"><div class="local-status" title="Данные сохранены локально в этом браузере"><span class="status-dot" aria-hidden="true"></span><span>LOCAL-FIRST</span></div><button class="sync-ai-button" type="button" data-placeholder="Панель локального ИИ и межустройственная синхронизация подключаются после базовых разделов.">${icon('bot')}<span>ИИ и синхронизация</span>${icon('chevron-right', 'chevron')}</button></div>
    </aside>
    <main class="workspace">
      <header class="workspace-header">
        <div><p class="eyebrow" data-page-kicker>PERSONAL CONTROL SURFACE</p><h1 data-page-title>Сегодняшний контур.</h1></div>
        <div class="header-actions"><button class="header-icon" type="button" data-view="calendar" aria-label="Быстрый переход к календарю">${icon('calendar-days')}</button><button class="header-icon" type="button" data-open-tags aria-label="Открыть категории">${icon('tags')}</button><button class="focus-button" type="button" data-placeholder="Настройка фокус-сессий станет доступна в следующем спринте">${icon('sparkles')}<span>Фокус</span></button></div>
      </header>
      <section class="app-view" data-app-view="dashboard" data-dashboard-module></section>
      <section class="app-view" data-app-view="tasks" hidden>
        <div class="dashboard-grid task-grid">
          <section class="daily-panel panel" data-todo-module aria-labelledby="daily-heading">
            <div class="panel-heading"><div><p class="eyebrow">DAILY TO-DO / LOCAL</p><h2 id="daily-heading">Задачи на сегодня</h2></div><div class="today-counter" aria-label="Количество задач"><span data-todo-count>00</span><small>ITEMS</small></div></div>
            <div class="daily-rule" aria-hidden="true"><span></span></div>
            <form class="quick-task-form" data-todo-quick-form><label class="sr-only" for="quick-task-input">Быстро добавить задачу</label><i data-lucide="plus" aria-hidden="true"></i><input id="quick-task-input" data-todo-quick-input type="text" maxlength="120" autocomplete="off" placeholder="Новая задача — Enter для сохранения" /><button class="quick-task-expand" type="button" data-action="open-create-task" aria-label="Открыть расширенную форму">${icon('sliders-horizontal')}</button><button class="quick-task-submit" type="submit" aria-label="Добавить задачу">${icon('arrow-up')}</button></form>
            <div class="task-filter-bar" role="group" aria-label="Фильтр задач"><button class="filter-button filter-button--active" type="button" data-filter="all" aria-pressed="true">Все</button><button class="filter-button" type="button" data-filter="today" aria-pressed="false">Сегодня</button><button class="filter-button" type="button" data-filter="upcoming" aria-pressed="false">Предстоящие</button></div>
            <div class="todo-scroll-area"><div class="todo-empty-state" data-todo-no-results hidden><div class="todo-empty-state__icon">${icon('radar')}</div><h3>В этом контуре тихо.</h3><p>Для выбранного фильтра нет задач. Добавьте новую строку или скорректируйте период.</p><button class="empty-state-action" type="button" data-action="open-create-task">${icon('plus')} Добавить задачу</button></div><section class="task-group" data-todo-active-section aria-labelledby="active-task-heading"><div class="task-group__heading"><p id="active-task-heading">АКТИВНЫЙ КОНТУР</p><span data-todo-active-count>00</span></div><div class="task-stack" data-todo-active-list></div></section><section class="task-group task-group--completed" data-todo-completed-section aria-labelledby="completed-task-heading" hidden><div class="task-group__heading"><p id="completed-task-heading">ВЫПОЛНЕННЫЕ ЗАДАЧИ</p><span data-todo-completed-count>00</span></div><div class="task-stack" data-todo-completed-list></div></section></div>
            <section class="tag-section tag-section--compact" aria-labelledby="tag-heading"><div class="tag-section__heading"><div><p class="eyebrow">CATEGORY SIGNALS</p><h3 id="tag-heading">Мои категории</h3></div><button class="add-tag-button" type="button" data-action="create-tag">${icon('plus')}<span>Категория</span></button></div><div class="tag-list tag-list--compact" data-tag-manager aria-live="polite"></div></section>
          </section>
          <section class="calendar-panel panel" data-calendar-module aria-labelledby="calendar-heading"><div class="calendar-panel__backdrop" aria-hidden="true"></div><div class="calendar-content"><div class="panel-heading calendar-heading"><div><p class="eyebrow">CALENDAR / LOCAL-FIRST</p><h2 id="calendar-heading" data-calendar-title></h2></div><div class="calendar-status"><span class="status-dot"></span> LIVE VIEW</div></div><div class="calendar-controls" aria-label="Управление календарём"><div class="calendar-navigation"><button class="calendar-control-button" type="button" data-calendar-action="previous" aria-label="Предыдущий период">${icon('chevron-left')}</button><button class="calendar-today-button" type="button" data-calendar-action="today" data-calendar-today>Сегодня</button><button class="calendar-control-button" type="button" data-calendar-action="next" aria-label="Следующий период">${icon('chevron-right')}</button></div><div class="calendar-view-switch" role="group" aria-label="Режим отображения"><button class="calendar-view-button" type="button" data-calendar-mode="month" aria-pressed="true">Месяц</button><button class="calendar-view-button" type="button" data-calendar-mode="week" aria-pressed="false">Неделя</button><button class="calendar-view-button" type="button" data-calendar-mode="day" aria-pressed="false">День</button></div></div><div class="calendar-view" data-calendar-view></div><div class="calendar-ledger" aria-label="Сводка периода"><div><span>DAY MARKER</span><strong data-current-day>--</strong></div><div><span>MONTH DAYS</span><strong data-month-days>--</strong></div><div><span>FOCUS SIGNAL</span><strong class="violet-readout" data-calendar-focus>STANDBY</strong></div></div><footer class="calendar-footer"><span>${icon('info')} <span data-calendar-footer-note>Запланированные задачи появятся здесь после первой записи.</span></span><button type="button" data-calendar-action="manage-tags">Настроить категории ${icon('arrow-up-right')}</button></footer></div></section>
        </div>
      </section>
      <section class="app-view" data-app-view="habits" data-habits-module hidden></section>
      <section class="app-view" data-app-view="books" data-books-module hidden></section>
    </main>
    <div class="toast-region" aria-live="polite" aria-atomic="true"></div>
  </div>
`;

const storage = new StorageManager();
const appState = new AppState(storage);
window.appState = appState;
const toastRegion = document.querySelector('.toast-region');
const routes = {
  dashboard: { title: 'Сегодняшний контур.', kicker: 'PERSONAL CONTROL SURFACE' },
  tasks: { title: 'Задачи и проекты.', kicker: 'DAILY TO-DO / LOCAL' },
  habits: { title: 'Ритм и дисциплина.', kicker: 'ANNUAL DISCIPLINE' },
  books: { title: 'Чтение и заметки.', kicker: 'LOCAL LIBRARY' },
};

function notify(message, kind = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast toast--${kind}`;
  toast.innerHTML = `${icon(kind === 'error' ? 'circle-alert' : kind === 'info' ? 'info' : 'check-circle-2')}<span></span>`;
  toast.querySelector('span').textContent = message;
  toastRegion.append(toast);
  refreshIcons();
  window.setTimeout(() => toast.classList.add('toast--leaving'), 3100);
  window.setTimeout(() => toast.remove(), 3380);
}

const tagManager = new TagManager({ storage: appState, root: document.querySelector('[data-tag-manager]'), notify });
const todoModule = new TodoModule({ storage: appState, tags: tagManager, root: document.querySelector('[data-todo-module]'), notify });
const calendarModule = new CalendarModule({ storage: appState, tags: tagManager, todo: todoModule, root: document.querySelector('[data-calendar-module]') });
const habitModule = new HabitModule({ storage: appState, root: document.querySelector('[data-habits-module]'), notify });
const bookModule = new BookModule({ storage: appState, root: document.querySelector('[data-books-module]'), notify });
const dashboardModule = new DashboardModule({ storage: appState, root: document.querySelector('[data-dashboard-module]'), notify });
tagManager.mount();
todoModule.mount();
calendarModule.mount();
habitModule.mount();
bookModule.mount();
dashboardModule.mount();

function goTo(view) {
  if (view === 'calendar') {
    goTo('tasks');
    document.querySelectorAll('[data-view]').forEach((button) => {
      const isCalendar = button.dataset.view === 'calendar';
      button.classList.toggle('nav-item--active', isCalendar && button.classList.contains('nav-item'));
      button.toggleAttribute('aria-current', isCalendar);
    });
    document.querySelector('[data-page-title]').textContent = 'Календарь и задачи.';
    document.querySelector('[data-page-kicker]').textContent = 'SCHEDULE / LOCAL-FIRST';
    calendarModule.focus();
    return;
  }
  if (!routes[view]) return;
  document.querySelectorAll('[data-app-view]').forEach((element) => { element.hidden = element.dataset.appView !== view; });
  document.querySelectorAll('[data-view]').forEach((button) => {
    const isActive = button.dataset.view === view;
    button.classList.toggle('nav-item--active', isActive && button.classList.contains('nav-item'));
    button.toggleAttribute('aria-current', isActive);
  });
  document.querySelector('[data-page-title]').textContent = routes[view].title;
  document.querySelector('[data-page-kicker]').textContent = routes[view].kicker;
  window.scrollTo({ top: 0, behavior: 'instant' });
  refreshIcons();
}

function refreshIcons() { window.lucide?.createIcons({ attrs: { 'stroke-width': 1.75 } }); }
function showPlaceholder(message) { notify(message, 'info'); }

document.addEventListener('click', (event) => {
  const viewTrigger = event.target.closest('[data-view]');
  if (viewTrigger) return goTo(viewTrigger.dataset.view);
  if (event.target.closest('[data-open-tags]') || event.target.closest('[data-action="create-tag"]')) return tagManager.openCreateModal();
  const placeholderTrigger = event.target.closest('[data-placeholder]');
  if (placeholderTrigger) showPlaceholder(placeholderTrigger.dataset.placeholder);
});
window.addEventListener('zenith:navigate', (event) => goTo(event.detail));
refreshIcons();
